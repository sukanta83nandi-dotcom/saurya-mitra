import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Lock, 
  FolderLock, 
  Plus, 
  Trash2, 
  Download, 
  FileText, 
  Calendar, 
  Search, 
  Layers, 
  Tag, 
  User, 
  Coins, 
  UploadCloud, 
  CheckCircle2, 
  FileCheck, 
  AlertCircle,
  HelpCircle,
  Clock,
  ShieldCheck,
  Building,
  HardDrive
} from 'lucide-react';
import { collection, query, orderBy, onSnapshot, addDoc, deleteDoc, doc, Timestamp, serverTimestamp } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { Language } from '../translations';
import { User as FirebaseUser } from 'firebase/auth';
import { LoginRequired } from './LoginRequired';

interface WarrantyLockerProps {
  language: Language;
  user: FirebaseUser | null;
  onLogin?: () => void;
}

interface WarrantyRecord {
  id: string;
  createdAt: Timestamp | any;
  vendorName: string;
  customerName: string;
  installationDate: string;
  systemSize: number;
  panelBrand: string;
  panelSerialNumbers: string;
  invoiceNo: string;
  warrantyCardNo: string;
  documentNotes: string;
  invoiceFileName?: string;
  warrantyCardFileName?: string;
  invoiceDataUrl?: string; // base64 representation
  warrantyCardDataUrl?: string; // base64 representation
}

export function WarrantyLocker({ language, user, onLogin }: WarrantyLockerProps) {
  const [warranties, setWarranties] = useState<WarrantyRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [successAnimation, setSuccessAnimation] = useState(false);

  // Form states
  const [vendorName, setVendorName] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [installationDate, setInstallationDate] = useState('');
  const [systemSize, setSystemSize] = useState('');
  const [panelBrand, setPanelBrand] = useState('Waaree');
  const [panelSerialNumbers, setPanelSerialNumbers] = useState('');
  const [invoiceNo, setInvoiceNo] = useState('');
  const [warrantyCardNo, setWarrantyCardNo] = useState('');
  const [documentNotes, setDocumentNotes] = useState('');

  // Uploaded files states
  const [invoiceFile, setInvoiceFile] = useState<File | null>(null);
  const [invoiceBase64, setInvoiceBase64] = useState<string>('');
  const [warrantyFile, setWarrantyFile] = useState<File | null>(null);
  const [warrantyBase64, setWarrantyBase64] = useState<string>('');

  const [dragActiveInvoice, setDragActiveInvoice] = useState(false);
  const [dragActiveWarranty, setDragActiveWarranty] = useState(false);

  const isBn = language === 'bn';

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    const q = query(
      collection(db, `users/${user.uid}/warranties`),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as WarrantyRecord[];
      setWarranties(data);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${user.uid}/warranties`);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  // Handle files
  const processFile = (file: File, type: 'invoice' | 'warranty') => {
    if (file.size > 800 * 1024) {
      alert(isBn 
        ? 'ফাইল সাইজ খুব বড়! কাস্টমার বিল ও কোড রেকর্ডের সুবিধার জন্য ৮০০KB-র নিচের কোনো ইমেজ বা পিডিএফ ডক সিলেক্ট করুন।' 
        : 'File size is too big! Please select an image or PDF under 800KB for clean cloud synchronization.'
      );
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      if (type === 'invoice') {
        setInvoiceFile(file);
        setInvoiceBase64(base64String);
      } else {
        setWarrantyFile(file);
        setWarrantyBase64(base64String);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'invoice' | 'warranty') => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file, type);
    }
  };

  const handleDrag = (e: React.DragEvent, zone: 'invoice' | 'warranty', active: boolean) => {
    e.preventDefault();
    e.stopPropagation();
    if (zone === 'invoice') setDragActiveInvoice(active);
    else setDragActiveWarranty(active);
  };

  const handleDrop = (e: React.DragEvent, zone: 'invoice' | 'warranty') => {
    e.preventDefault();
    e.stopPropagation();
    if (zone === 'invoice') setDragActiveInvoice(false);
    else setDragActiveWarranty(false);

    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file, zone);
    }
  };

  const resetForm = () => {
    setVendorName('');
    setCustomerName('');
    setInstallationDate('');
    setSystemSize('');
    setPanelBrand('Waaree');
    setPanelSerialNumbers('');
    setInvoiceNo('');
    setWarrantyCardNo('');
    setDocumentNotes('');
    setInvoiceFile(null);
    setInvoiceBase64('');
    setWarrantyFile(null);
    setWarrantyBase64('');
  };

  const handleSaveWarranty = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    if (!vendorName || !customerName || !panelBrand || !invoiceNo || !warrantyCardNo) {
      alert(isBn ? 'দয়া করে সব আবশ্যক ক্ষেত্রগুলো পূরণ করুন।' : 'Please fill all required mandatory fields.');
      return;
    }

    setSaving(true);
    try {
      const payload = {
        createdAt: serverTimestamp(),
        vendorName,
        customerName,
        installationDate: installationDate || new Date().toISOString().split('T')[0],
        systemSize: systemSize ? Number(systemSize) : 3,
        panelBrand,
        panelSerialNumbers: panelSerialNumbers || 'N/A',
        invoiceNo,
        warrantyCardNo,
        documentNotes: documentNotes || '',
        invoiceFileName: invoiceFile ? invoiceFile.name : '',
        warrantyCardFileName: warrantyFile ? warrantyFile.name : '',
        invoiceDataUrl: invoiceBase64 || '',
        warrantyCardDataUrl: warrantyBase64 || '',
      };

      await addDoc(collection(db, `users/${user.uid}/warranties`), payload);
      setSuccessAnimation(true);
      setTimeout(() => {
        setSuccessAnimation(false);
        setShowAddForm(false);
        resetForm();
      }, 2000);
    } catch (err) {
      console.error("Save warranty error: ", err);
      alert(isBn ? 'সংরক্ষণ ব্যর্থ হয়েছে। আবার চেষ্টা করুন।' : 'Failed to save warranty record. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!user) return;
    if (!window.confirm(isBn ? 'আপনি কি নিশ্চিতভাবে এই রেকর্ডটি মুছে ফেলতে চান?' : 'Are you sure you want to securely delete this warranty locker record?')) {
      return;
    }

    try {
      await deleteDoc(doc(db, `users/${user.uid}/warranties`, id));
    } catch (err) {
      console.error(err);
      alert(isBn ? 'মুছে ফেলতে ব্যর্থ হয়েছে।' : 'Failed to delete record.');
    }
  };

  const triggerDownload = (dataUrl: string, fileName: string) => {
    if (!dataUrl) return;
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = fileName || 'solar_document';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (!user) {
    return <LoginRequired language={language} onLogin={onLogin} />;
  }

  // Filtered list
  const filteredWarranties = warranties.filter(w => {
    const term = searchQuery.toLowerCase();
    return (
      w.customerName.toLowerCase().includes(term) ||
      w.vendorName.toLowerCase().includes(term) ||
      w.panelBrand.toLowerCase().includes(term) ||
      w.invoiceNo.toLowerCase().includes(term) ||
      w.warrantyCardNo.toLowerCase().includes(term) ||
      w.panelSerialNumbers.toLowerCase().includes(term)
    );
  });

  // Calculate stats
  const totalCapacity = warranties.reduce((acc, w) => acc + (w.systemSize || 0), 0);
  const uniqueBrands = Array.from(new Set(warranties.map(w => w.panelBrand))).length;

  return (
    <div className="space-y-8 max-w-6xl mx-auto px-1 md:px-4">
      
      {/* Top Locker Intro Card */}
      <div className="bg-gradient-to-br from-emerald-800 via-emerald-900 to-slate-900 text-white p-6 md:p-10 rounded-[2.5rem] shadow-xl relative overflow-hidden text-left border border-emerald-700/30">
        <div className="absolute right-0 top-0 w-80 h-80 bg-white/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-10 -bottom-10 w-60 h-60 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="max-w-3xl space-y-4 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-400 text-slate-950 rounded-full text-[10px] font-black uppercase tracking-widest shadow-md shadow-amber-500/20">
            <Lock className="w-3 h-3 fill-slate-950" />
            {isBn ? 'নিরাপদ ক্লাউড লকার ২০২৬' : 'Secure Cloud Locker 2026'}
          </div>
          <h2 className="text-3xl md:text-5xl font-black tracking-tight leading-tight">
            {isBn ? 'ডিজিটাল ওয়ারেন্টি লকার' : 'Warranty Vault Locker'}
          </h2>
          <p className="text-sm md:text-base font-semibold text-emerald-100/90 leading-relaxed">
            {isBn 
              ? 'নিবন্ধিত সৌরমিত্র ভেন্ডর ও গ্রাহকদের জন্য সোলার ইন্টিগ্রিটি প্ল্যাটফর্ম। এখানে নিশ্চিন্তে আপলোড ও সুরক্ষিত করুন আপনার সোলার সিস্টেমের সমস্ত ট্যাক্স বিল, সিরিয়াল নাম্বার ট্র্যাক ও অফিশিয়াল প্রস্তুতকারক ওয়ারেন্টি কার্ড।'
              : 'A secure cloud vault tailored for authorized solar installers, vendors, and plant owners. Register physical PV panel serials, upload tax invoice scans, and lock certificates safely with infinite local retrievals.'}
          </p>
        </div>

        {/* Stats strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8 pt-6 border-t border-white/10">
          <div className="p-3 bg-white/5 rounded-2xl border border-white/5 text-left">
            <span className="text-[10px] font-bold text-emerald-300 block tracking-widest uppercase">{isBn ? 'মোট সুরক্ষিত ফাইল' : 'SECURED FILES'}</span>
            <span className="text-2xl font-black text-white">{warranties.length} {isBn ? 'টি' : 'records'}</span>
          </div>
          <div className="p-3 bg-white/5 rounded-2xl border border-white/5 text-left">
            <span className="text-[10px] font-bold text-emerald-300 block tracking-widest uppercase">{isBn ? 'সোলার শক্তি ট্র্যাকিং' : 'CAPACITY TRACKED'}</span>
            <span className="text-2xl font-black text-white">{totalCapacity.toFixed(1)} kW</span>
          </div>
          <div className="p-3 bg-white/5 rounded-2xl border border-white/5 text-left">
            <span className="text-[10px] font-bold text-emerald-300 block tracking-widest uppercase">{isBn ? 'সক্রিয় ব্র্যান্ডসমূহ' : 'BRANDS REGISTERED'}</span>
            <span className="text-2xl font-black text-white">{uniqueBrands}</span>
          </div>
          <div className="p-3 bg-white/5 rounded-2xl border border-white/5 text-left">
            <span className="text-[10px] font-bold text-emerald-300 block tracking-widest uppercase">{isBn ? 'সুরক্ষা এনক্রিপশন' : 'ENCRYPTION'}</span>
            <span className="text-sm font-black text-amber-400 flex items-center gap-1 mt-1">
              <ShieldCheck className="w-4 h-4 text-amber-400 inline" /> AES-256
            </span>
          </div>
        </div>
      </div>

      {/* Button and search layout bar */}
      <div className="flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between">
        
        {/* Search input */}
        <div className="relative flex-1 max-w-md">
          <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
            <Search className="w-5 h-5" />
          </span>
          <input
            type="text"
            placeholder={isBn ? 'গ্রাহকের নাম, ইনভয়েস নম্বর বা সিরিয়াল দিয়ে খুঁজুন...' : 'Search by Customer, Invoice, Brand or Serial...'}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-11 pr-4 py-3 bg-white border border-gray-200 rounded-2xl text-sm font-semibold text-slate-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent tracking-wide"
          />
        </div>

        {/* Action button */}
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="px-6 py-3.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-extrabold text-sm rounded-2xl transition duration-150 flex items-center justify-center gap-2 shadow-lg shadow-emerald-200"
        >
          {showAddForm ? (
            <>
              <Lock className="w-4 h-4" />
              {isBn ? 'লকার ভিউ দেখুন' : 'View Locked Records'}
            </>
          ) : (
            <>
              <Plus className="w-4.5 h-4.5 stroke-[3]" />
              {isBn ? 'নতুন ডকুমেন্ট যোগ করুন' : 'Lock New Document'}
            </>
          )}
        </button>
      </div>

      {/* Main Panel Content */}
      <AnimatePresence mode="wait">
        {showAddForm ? (
          <motion.div
            key="add-form"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white border border-gray-100 rounded-[2.5rem] p-6 md:p-10 shadow-lg text-left relative overflow-hidden"
          >
            {/* Success animations overlap */}
            {successAnimation && (
              <div className="absolute inset-0 bg-white/95 z-50 flex flex-col items-center justify-center space-y-4">
                <motion.div 
                  initial={{ scale: 0.5, rotate: -45 }}
                  animate={{ scale: 1, rotate: 0 }}
                  className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600"
                >
                  <CheckCircle2 className="w-12 h-12 stroke-[2.5]" />
                </motion.div>
                <div className="text-center">
                  <h4 className="text-2xl font-black text-slate-900">{isBn ? 'লকারে সফলভাবে সংরক্ষিত হয়েছে!' : 'Securely Lodged in Vault!'}</h4>
                  <p className="text-sm text-gray-500 font-bold mt-1 uppercase tracking-widest">{isBn ? 'এনক্রিপ্টেড ডাটাবেজ আপডেট সম্পন্ন হয়েছে' : 'Cloud Sync and encryption finalized'}</p>
                </div>
              </div>
            )}

            <div className="border-b border-gray-100 pb-5 mb-8">
              <h3 className="text-xl font-black text-slate-900 flex items-center gap-2">
                <FolderLock className="text-emerald-600 w-6 h-6" />
                {isBn ? 'নতুন ওয়ারেন্টি ও ইনভয়েস বিবরণী দাখিল করুন' : 'Submit New System Warranty details'}
              </h3>
              <p className="text-xs text-gray-400 font-bold uppercase tracking-wider mt-1">{isBn ? 'সব আবশ্যক ক্ষেত্র পূরণ করুন এবং ফাইল আপলোড করুন' : 'Please upload file attachments and enter system metrics'}</p>
            </div>

            <form onSubmit={handleSaveWarranty} className="space-y-8">
              {/* Core 2x2 fields */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Vendor Name */}
                <div className="space-y-1.5">
                  <label className="text-xs font-black uppercase text-slate-700 tracking-wider flex items-center gap-1.5 matches-feedback">
                    <Building className="w-3.5 h-3.5 text-emerald-600" />
                    {isBn ? 'ভেন্ডর প্রতিষ্ঠানের নাম' : 'Authorized Vendor Name'} <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={vendorName}
                    onChange={(e) => setVendorName(e.target.value)}
                    placeholder={isBn ? 'যেমন: এস আর সোলার সার্ভিসেস' : 'e.g., S.R. Solar Solutions'}
                    className="w-full p-3.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold transition focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:bg-white"
                  />
                </div>

                {/* Customer Name */}
                <div className="space-y-1.5">
                  <label className="text-xs font-black uppercase text-slate-700 tracking-wider flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-emerald-600" />
                    {isBn ? 'গ্রাহক / প্ল্যান্ট মালিকের নাম' : 'Customer / Owner Name'} <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder={isBn ? 'যেমন: সুকান্ত নন্দী' : 'e.g., Sukanta Nandi'}
                    className="w-full p-3.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold transition focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:bg-white"
                  />
                </div>

                {/* Installation Date */}
                <div className="space-y-1.5">
                  <label className="text-xs font-black uppercase text-slate-700 tracking-wider flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                    {isBn ? 'ইনস্টলেশন সম্পন্ন হওয়ার তারিখ' : 'Commissioning Date'}
                  </label>
                  <input
                    type="date"
                    value={installationDate}
                    onChange={(e) => setInstallationDate(e.target.value)}
                    className="w-full p-3.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold transition focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:bg-white"
                  />
                </div>

                {/* System Capacity */}
                <div className="space-y-1.5">
                  <label className="text-xs font-black uppercase text-slate-700 tracking-wider flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-emerald-600" />
                    {isBn ? 'সিস্টেমের মোট সাইজ (কিলোওয়াট)' : 'System Capacity (kW)'}
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={systemSize}
                    onChange={(e) => setSystemSize(e.target.value)}
                    placeholder="e.g., 5.0"
                    className="w-full p-3.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold transition focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:bg-white"
                  />
                </div>

                {/* Panel Brand */}
                <div className="space-y-1.5">
                  <label className="text-xs font-black uppercase text-slate-700 tracking-wider flex items-center gap-1.5">
                    <Tag className="w-3.5 h-3.5 text-emerald-600" />
                    {isBn ? 'সোলার প্যানেলের ব্র্যান্ড প্রস্তুতকারক' : 'Solar Panel Brand / Tier-1'} <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={panelBrand}
                    onChange={(e) => setPanelBrand(e.target.value)}
                    className="w-full p-3.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold transition focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:bg-white text-slate-800"
                  >
                    <option value="Waaree">Waaree Energy</option>
                    <option value="Vikram">Vikram Solar</option>
                    <option value="Tata">Tata Power Solar</option>
                    <option value="Adani">Adani Solar</option>
                    <option value="Luminous">Luminous Solar</option>
                    <option value="Servotech">Servotech</option>
                    <option value="Goldi">Goldi Solar</option>
                    <option value="Other">Other Brand</option>
                  </select>
                </div>

                {/* Invoice Certificate number */}
                <div className="space-y-1.5">
                  <label className="text-xs font-black uppercase text-slate-700 tracking-wider flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-emerald-600" />
                    {isBn ? 'ট্যাক্স ইনভয়েস নম্বর' : 'Tax Invoice Number'} <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={invoiceNo}
                    onChange={(e) => setInvoiceNo(e.target.value)}
                    placeholder="e.g., INV/2026/4098"
                    className="w-full p-3.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold transition focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:bg-white"
                  />
                </div>

                {/* Warranty Card Serial Number */}
                <div className="space-y-1.5">
                  <label className="text-xs font-black uppercase text-slate-700 tracking-wider flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    {isBn ? 'অফিশিয়াল ওয়ারেন্টি কার্ড নাম্বার' : 'Official Warranty Book/Card No.'} <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={warrantyCardNo}
                    onChange={(e) => setWarrantyCardNo(e.target.value)}
                    placeholder="e.g., WC-WAR-887E-8902"
                    className="w-full p-3.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold transition focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:bg-white"
                  />
                </div>

                {/* Serial Numbers array string */}
                <div className="space-y-1.5">
                  <label className="text-xs font-black uppercase text-slate-700 tracking-wider flex items-center gap-1.5">
                    <Coins className="w-3.5 h-3.5 text-emerald-600" />
                    {isBn ? 'সোলার প্যানেল সিরিয়াল নম্বরসমূহ' : 'PV Panels Serial Numbers (comma-sep)'}
                  </label>
                  <input
                    type="text"
                    value={panelSerialNumbers}
                    onChange={(e) => setPanelSerialNumbers(e.target.value)}
                    placeholder={isBn ? 'যেমন: SN873092, SN873093, SN873094...' : 'e.g., WAA2605-09121, WAA2605-09122...'}
                    className="w-full p-3.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold transition focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:bg-white"
                  />
                </div>
              </div>

              {/* Extra Document notes */}
              <div className="space-y-1.5">
                <label className="text-xs font-black uppercase text-slate-700 tracking-wider">
                  {isBn ? 'কোনো অতিরিক্ত বিবরণ অথবা মন্তব্য' : 'Additional Document Notes / Commission Remarks'}
                </label>
                <textarea
                  value={documentNotes}
                  onChange={(e) => setDocumentNotes(e.target.value)}
                  rows={3}
                  placeholder={isBn ? 'যেমন: আর্থিং রেজিস্ট্যান্স টেস্ট ভ্যালু ও অন্যান্য বিবরণ...' : 'e.g. Earth resistance at 1.8 Ohms, structural angles secured perfectly, 10 Awg cables...'}
                  className="w-full p-3.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold transition focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:bg-white"
                />
              </div>

              {/* Two Premium Document File Uploader Dropzones */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Invoice File */}
                <div className="space-y-2">
                  <span className="text-xs font-black uppercase text-slate-700 tracking-wider block">
                    {isBn ? '১. ট্যাক্স ইনভয়েস ডকুমেন্ট আপলোড' : '1. Upload Tax Invoice File'}
                  </span>
                  
                  <div
                    onDragOver={(e) => handleDrag(e, 'invoice', true)}
                    onDragLeave={(e) => handleDrag(e, 'invoice', false)}
                    onDrop={(e) => handleDrop(e, 'invoice')}
                    className={`border-2 border-dashed rounded-3xl p-6 text-center cursor-pointer transition flex flex-col items-center justify-center space-y-2 select-none relative ${
                      dragActiveInvoice ? 'border-emerald-500 bg-emerald-50/50' : 'border-gray-200 hover:border-emerald-300 hover:bg-gray-50/30'
                    }`}
                  >
                    <input
                      type="file"
                      id="invoice-upload"
                      accept="image/*,.pdf"
                      onChange={(e) => handleFileChange(e, 'invoice')}
                      className="hidden"
                    />
                    <label htmlFor="invoice-upload" className="cursor-pointer flex flex-col items-center justify-center space-y-2">
                      <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center shadow-inner">
                        {invoiceFile ? <FileCheck className="w-6 h-6 text-emerald-600 animate-bounce" /> : <UploadCloud className="w-6 h-6 text-emerald-500" />}
                      </div>
                      <div>
                        {invoiceFile ? (
                          <div className="space-y-1">
                            <span className="text-xs font-black text-slate-800 block truncate max-w-[250px]">{invoiceFile.name}</span>
                            <span className="text-[10px] text-gray-400 font-bold">{(invoiceFile.size / 1024).toFixed(0)} KB</span>
                          </div>
                        ) : (
                          <>
                            <span className="text-xs font-black text-slate-800 block">{isBn ? 'ট্যাক্স ইনভয়েস ফাইল ড্র্যাগ করুন অথবা ক্লিক করে পছন্দ করুন' : 'Drag or click to choose Tax Invoice file'}</span>
                            <span className="text-[10px] text-gray-400 font-bold block mt-0.5">{isBn ? 'সর্বোচ্চ ৮০০KB (PNG, JPG, PDF)' : 'Max size 800KB (PNG, JPG, PDF)'}</span>
                          </>
                        )}
                      </div>
                    </label>
                  </div>
                </div>

                {/* Warranty Card File */}
                <div className="space-y-2">
                  <span className="text-xs font-black uppercase text-slate-700 tracking-wider block">
                    {isBn ? '২. প্রস্তুতকারক ওয়ারেন্টি কার্ড ফাইল আপলোড' : '2. Upload Manufacturer Warranty Card'}
                  </span>
                  
                  <div
                    onDragOver={(e) => handleDrag(e, 'warranty', true)}
                    onDragLeave={(e) => handleDrag(e, 'warranty', false)}
                    onDrop={(e) => handleDrop(e, 'warranty')}
                    className={`border-2 border-dashed rounded-3xl p-6 text-center cursor-pointer transition flex flex-col items-center justify-center space-y-2 select-none relative ${
                      dragActiveWarranty ? 'border-emerald-500 bg-emerald-50/50' : 'border-gray-200 hover:border-emerald-300 hover:bg-gray-50/30'
                    }`}
                  >
                    <input
                      type="file"
                      id="warranty-upload"
                      accept="image/*,.pdf"
                      onChange={(e) => handleFileChange(e, 'warranty')}
                      className="hidden"
                    />
                    <label htmlFor="warranty-upload" className="cursor-pointer flex flex-col items-center justify-center space-y-2">
                      <div className="w-12 h-12 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center shadow-inner">
                        {warrantyFile ? <FileCheck className="w-6 h-6 text-indigo-600 animate-bounce" /> : <UploadCloud className="w-6 h-6 text-indigo-500" />}
                      </div>
                      <div>
                        {warrantyFile ? (
                          <div className="space-y-1">
                            <span className="text-xs font-black text-slate-800 block truncate max-w-[250px]">{warrantyFile.name}</span>
                            <span className="text-[10px] text-gray-400 font-bold">{(warrantyFile.size / 1024).toFixed(0)} KB</span>
                          </div>
                        ) : (
                          <>
                            <span className="text-xs font-black text-slate-800 block">{isBn ? 'ওয়ারেন্টি প্রমাণ ফাইলটি ড্র্যাগ করুন অথবা ক্লিক করে সিলেক্ট করুন' : 'Drag or click to choose Warranty proof'}</span>
                            <span className="text-[10px] text-gray-400 font-bold block mt-0.5">{isBn ? 'সর্বোচ্চ ৮০০KB (PNG, JPG, PDF)' : 'Max size 800KB (PNG, JPG, PDF)'}</span>
                          </>
                        )}
                      </div>
                    </label>
                  </div>
                </div>

              </div>

              {/* Submit Buttons */}
              <div className="flex gap-4 pt-4 border-t border-gray-100 justify-end">
                <button
                  type="button"
                  onClick={() => { setShowAddForm(false); resetForm(); }}
                  className="px-5 py-3 border border-gray-200 rounded-xl font-bold text-xs md:text-sm text-gray-500 hover:bg-gray-50 transition"
                >
                  {isBn ? 'বাতিল করুন' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-extrabold text-xs md:text-sm rounded-xl transition flex items-center justify-center gap-2 shadow-md disabled:opacity-40"
                >
                  {saving && <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />}
                  {isBn ? 'ফাইলটি লকারে লক করুন' : 'Secure Document In Locker'}
                </button>
              </div>

            </form>
          </motion.div>
        ) : (
          /* List warranties grid view */
          <motion.div
            key="warranties-list"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="space-y-6 text-left"
          >
            {loading ? (
              <div className="flex justify-center py-20">
                <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
              </div>
            ) : filteredWarranties.length === 0 ? (
              <div className="text-center py-16 bg-white rounded-[2rem] border border-gray-100 p-8 space-y-4">
                <div className="w-14 h-14 bg-amber-50 rounded-full flex items-center justify-center text-amber-500 mx-auto">
                  <HardDrive className="w-7 h-7" />
                </div>
                <div className="space-y-1">
                  <h4 className="font-extrabold text-slate-800 text-lg">
                    {isBn ? 'লকার আপাততঃ খালি আছে।' : 'Warranty Locker is empty!'}
                  </h4>
                  <p className="text-sm text-gray-400 font-semibold max-w-sm mx-auto">
                    {isBn 
                      ? 'এখনো কোনো ওয়ারেন্টি বা ট্যাক্স বিল বিবরণী আপলোড করা হয়নি। "নতুন ডকুমেন্ট যোগ করুন" বাটনে ক্লিক করে প্রথম ফাইলটি রাখুন।'
                      : 'No warranty entries registered on your account yet. Fill standard solar metadata and lock your certificates safely.'}
                  </p>
                </div>
              </div>
            ) : (
              /* Grid Layout mapping */
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredWarranties.map((item) => (
                  <motion.div
                    key={item.id}
                    layout
                    whileHover={{ y: -3, boxShadow: "0 12px 24px -10px rgba(0,0,0,0.06)" }}
                    className="bg-[#FCFBF7] border border-amber-200/50 rounded-3xl p-6 relative overflow-hidden flex flex-col justify-between"
                  >
                    {/* Brand Banner Strip inside the card */}
                    <div className="absolute top-0 right-0 bg-emerald-500 text-white font-black text-[10px] tracking-widest uppercase px-4 py-1.5 rounded-bl-2xl">
                      {item.panelBrand}
                    </div>

                    <div className="space-y-4">
                      {/* Customer / Installation date */}
                      <div className="flex items-start gap-3.5 border-b border-amber-200/20 pb-3">
                        <div className="w-10 h-10 rounded-xl bg-amber-100/60 text-amber-800 flex items-center justify-center flex-shrink-0">
                          <User className="w-5 h-5" />
                        </div>
                        <div className="space-y-0.5 max-w-[200px]">
                          <h4 className="font-extrabold text-slate-800 text-base truncate leading-snug">
                            {item.customerName}
                          </h4>
                          <span className="text-[10px] text-gray-400 font-extrabold tracking-wider block">
                            {isBn ? 'ইনস্টল:' : 'INSTALLED:'} {item.installationDate}
                          </span>
                        </div>
                      </div>

                      {/* Info grid mapping details */}
                      <div className="grid grid-cols-2 gap-y-3 gap-x-1.5 font-semibold text-xs text-slate-700">
                        <div>
                          <span className="text-[9px] font-black text-gray-400 block tracking-wider uppercase">{isBn ? 'সিস্টেম সাইজ' : 'SYSTEM CAPACITY'}</span>
                          <span className="text-sm font-extrabold text-slate-800">{item.systemSize} kW</span>
                        </div>
                        <div>
                          <span className="text-[9px] font-black text-gray-400 block tracking-wider uppercase">{isBn ? 'ভেন্ডর' : 'VENDOR NAME'}</span>
                          <span className="text-sm font-extrabold text-slate-800 truncate block max-w-[130px]">{item.vendorName}</span>
                        </div>
                        <div>
                          <span className="text-[9px] font-black text-gray-400 block tracking-wider uppercase">{isBn ? 'ইনভয়েস নম্বর' : 'INVOICE NUMBER'}</span>
                          <span className="text-xs font-bold text-slate-800">{item.invoiceNo}</span>
                        </div>
                        <div>
                          <span className="text-[9px] font-black text-gray-400 block tracking-wider uppercase">{isBn ? 'ওয়ারেন্টি কার্ড নম্বর' : 'WARRANTY BOOK NO.'}</span>
                          <span className="text-xs font-bold text-slate-800">{item.warrantyCardNo}</span>
                        </div>
                      </div>

                      {/* Display panel serial code block */}
                      {item.panelSerialNumbers && item.panelSerialNumbers !== 'N/A' && (
                        <div className="p-2.5 bg-slate-900/5 border border-slate-900/5 rounded-xl text-left space-y-1">
                          <span className="text-[8px] font-black text-slate-400 block tracking-widest uppercase">{isBn ? 'প্যানেল সিরিয়াল কোডস' : 'PV SERIAL NUMBERS'}</span>
                          <p className="text-[10px] font-mono text-slate-600 truncate">{item.panelSerialNumbers}</p>
                        </div>
                      )}

                      {/* Document notes */}
                      {item.documentNotes && (
                        <p className="text-[11px] text-gray-500 italic bg-amber-50/20 p-2.5 rounded-xl border border-amber-200/10 font-bold leading-normal">
                          &ldquo;{item.documentNotes}&rdquo;
                        </p>
                      )}
                    </div>

                    {/* Footer Buttons download / delete */}
                    <div className="flex items-center justify-between border-t border-amber-200/20 pt-4.5 mt-5">
                      
                      {/* Attached files status and downloads */}
                      <div className="flex gap-2">
                        {item.invoiceDataUrl ? (
                          <button
                            onClick={() => triggerDownload(item.invoiceDataUrl!, item.invoiceFileName || `Invoice-${item.invoiceNo}.png`)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 hover:bg-amber-100/80 border border-amber-200/40 text-amber-900 font-extrabold text-[10px] rounded-xl transition duration-100"
                            title={isBn ? 'ট্যাক্স ইনভয়েস ডাউনলোড করুন' : 'Download Tax Invoice'}
                          >
                            <Download className="w-3.5 h-3.5" />
                            {isBn ? 'ইনভয়েস' : 'Invoice'}
                          </button>
                        ) : (
                          <span className="text-[10px] text-gray-400 bg-gray-50 border border-gray-100 px-2 py-1 rounded-lg italic font-bold">
                            {isBn ? 'ইনভয়েস নেই' : 'No Invoice File'}
                          </span>
                        )}

                        {item.warrantyCardDataUrl ? (
                          <button
                            onClick={() => triggerDownload(item.warrantyCardDataUrl!, item.warrantyCardFileName || `Warranty-${item.warrantyCardNo}.png`)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100/80 border border-indigo-200/40 text-indigo-950 font-extrabold text-[10px] rounded-xl transition duration-100"
                            title={isBn ? 'ওয়ারেন্টি কার্ড বুকলেট ডাউনলোড' : 'Download Warranty book'}
                          >
                            <Download className="w-3.5 h-3.5" />
                            {isBn ? 'ওয়ারেন্টি ডক' : 'Warranty Doc'}
                          </button>
                        ) : (
                          <span className="text-[10px] text-gray-400 bg-gray-50 border border-gray-100 px-2 py-1 rounded-lg italic font-bold">
                            {isBn ? 'ওয়ারেন্টি নেই' : 'No Warranty File'}
                          </span>
                        )}
                      </div>

                      {/* Delete record */}
                      <button
                        onClick={() => handleDelete(item.id)}
                        className="p-2 text-rose-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition transition-colors"
                        title={isBn ? 'রেকর্ডটি ডিলিট করুন' : 'Delete certificate'}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>

                    </div>

                  </motion.div>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  FileText, 
  ShieldCheck, 
  CheckCircle, 
  AlertTriangle, 
  Lock, 
  ChevronDown 
} from 'lucide-react';
import { Language } from '../translations';

interface ClaimProcessProps {
  language: Language;
}

export function ClaimProcess({ language }: ClaimProcessProps) {
  const [expandedStep, setExpandedStep] = useState<number | null>(null);
  const [documentChecklist, setDocumentChecklist] = useState<Record<string, boolean>>({
    invoice: false,
    warrantyCard: false,
    serials: false,
    installReport: false,
    mediaEvidence: false,
  });

  const toggleDoc = (key: string) => {
    setDocumentChecklist(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const isBn = language === 'bn';

  const content = {
    title: isBn ? 'সোলার প্যানেলের ওয়ারেন্টি ক্লেইম করার প্রক্রিয়া' : 'Solar Panel Warranty Claim Process',
    subtitle: isBn 
      ? 'আপনার সোলার প্যানেলের কোম্পানি ওয়ারেন্টি ক্লেইম করার সঠিক নিয়ম ও গাইডলাইন' 
      : 'Step-by-step regulatory instructions to claim manufacturer warranty for your solar system',
    intro: isBn
      ? 'সোলার প্যানেলের ওয়ারেন্টি ক্লেইম করার প্রক্রিয়াটি একটু সময়সাপেক্ষ হতে পারে, তাই সঠিক ডকুমেন্টেশন এবং সঠিক পদ্ধতি জানা থাকলে কাজ অনেক সহজ হয়ে যায়। সাধারণত সোলার প্যানেলে ২ ধরণের ওয়ারেন্টি থাকে:'
      : 'Claiming a manufacturer warranty for solar panels can seem daunting, but having complete folder of precise documentation makes the procedure fast and seamless. Typically, panels include two kinds of warranties:',
    
    warnP1: isBn ? '১. প্রোডাক্ট ওয়ারেন্টি (১০ - ১২ বছর):' : '1. Product Warranty (10 - 12 Years):',
    warnD1: isBn 
      ? 'প্যানেলের গ্লাস, ফ্রেমিং, তার বা মেকানিক্যাল ত্রুটির বিরুদ্ধে সুরক্ষা।'
      : 'Protects against micro-cracks, frame decay, glass shattering, or physical structural failures.',
    warnP2: isBn ? '২. পারফরম্যান্স ও পাওয়ার ওয়ারেন্টি (২৫ বছর):' : '2. Performance Warranty (25 Years):',
    warnD2: isBn 
      ? '২৫ বছরে কমপক্ষে ৮০-৮৫% পর্যন্ত বিদ্যুৎ উৎপাদন ক্ষমতা বজায় রাখার নিশ্চয়তা।'
      : 'Guarantees the power production rate does not decay below 80-85% at the end of 25 years.',

    sec1Title: isBn ? '১. প্রয়োজনীয় ডকুমেন্টের তালিকা (Checklist)' : '1. Required Documents Checklist',
    sec1Sub: isBn ? 'ক্লেইম দায়ের করার পূর্বে নিচে উল্লেখিত কাগজগুলো গুছিয়ে রাখুন:' : 'Keep these documents compiled and ready before attempting to appeal with the manufacturer:',

    docs: [
      {
        id: 'invoice',
        title: isBn ? 'আসল ট্যাক্স ইনভয়েস (Original Tax Invoice)' : 'Original Tax Invoice',
        desc: isBn 
          ? 'কেনার সময় রেজিস্টার্ড সৌরমিত্র ভেন্ডর বা ডিস্ট্রিবিউটর থেকে দেওয়া আসল বিল। এতে প্যানেলের সঠিক ব্র্যান্ড ও মডেল নম্বর থাকা বাধ্যতামূলক।'
          : 'Original physical/PDF tax invoice given by the solar vendor. Mandatory to prove the exact brand, purchase price, date, and models.'
      },
      {
        id: 'warrantyCard',
        title: isBn ? 'অফিশিয়াল ওয়ারেন্টি কার্ড (Warranty Card)' : 'Official Warranty Card',
        desc: isBn 
          ? 'প্লাস্টিক বা কাগজের অফিশিয়াল গ্যাজেট স্ট্যাম্প সহ ওয়ারেন্টি ম্যানুফ্যাকচারার বুকলেট।'
          : 'Official stamped warranty certificate provided in the accessory kit during commissioning.'
      },
      {
        id: 'serials',
        title: isBn ? 'প্যানেল সিরিয়াল নম্বর (Serial Numbers)' : 'Solar Panel Serial Numbers',
        desc: isBn 
          ? 'প্রতিটি প্যানেল ব্যাক প্লেটের পেছনে একটি বারকোড সহ সম্পূর্ণ ইউনিক আলফানিউমেরিক সিরিয়াল নম্বর আঁকা থাকে। এটি ক্লেইমের প্রধান চাবিকাঠি।'
          : 'Universal barcode stickers attached firmly on the underside of every individual PV panel module. Essential core identifier.'
      },
      {
        id: 'installReport',
        title: isBn ? 'ইনস্টলেশন ও ফিটিং রিপোর্ট (Installation Report)' : 'Installation & Commissioning Report',
        desc: isBn 
          ? 'গ্রিড কানেক্টিভিটি সম্পন্ন ইনস্টলারদের দিয়ে করা সফল টেস্টিং-রিপোর্টের অনুলিপি।'
          : 'The certified commissioning checklist sheet signed by the government registered empanelled vendor.'
      },
      {
        id: 'mediaEvidence',
        title: isBn ? 'ছবি ও ভিডিওর প্রমাণ (Physical / Output Evidence)' : 'Evidence Photos & Log Records',
        desc: isBn 
          ? 'প্যানেলের বাহ্যিক ফিজিক্যাল ক্ষতির স্পষ্ট ছবি অথবা ইনভার্টার রিডিংয়ের স্ক্রিনশট, যা দিয়ে বিদ্যুৎ উৎপাদন হ্রাসের বিষয়টি পরিষ্কার প্রমাণিত হয়।'
          : 'Clear resolution pictures of physical defects (glass shatter, discoloration) or inverter generation log summaries verifying reduced kWh production.'
      }
    ],

    sec2Title: isBn ? '২. ওয়ারেন্টি ক্লেইম করার ধাপে ধাপে পদ্ধতি (Step-by-Step)' : '2. Step-by-Step Claim Flow Procedure',
    sec2Desc: isBn 
      ? 'ক্লেইম আবেদন প্রক্রিয়া সহজ করতে নিচের ৪টি যৌক্তিক ধাপ ক্রমানুসারে অনুসরণ করুন:'
      : 'To guarantee a successful outcome, follow these 4 structured steps sequentially in order:',

    steps: [
      {
        num: 'ধাপ ১',
        numEn: 'Step 1',
        title: isBn ? 'ভেন্ডর অথবা কাস্টমার সার্ভিসের সাথে প্রথম যোগাযোগ' : 'Initiate Contact with Vendor or Manufacturer',
        desc: isBn 
          ? 'সবার আগে প্যানেল স্থাপনকারী আসল ভেন্ডরকে টিকিট জানান। যদি তারা অবহেলা করে, তবে সরাসরি প্রস্তুতকারক কোম্পানির কাস্টমার কেয়ার সার্ভিস ইমেল বা টোল-ফ্রি হেল্পলাইনে যোগাযোগ করুন।'
          : 'Notify your solar installation vendor first. If you face delays, contact the corporate brand manufacturer customer care directly via their online portal or 1-800 toll-free inquiry line.'
      },
      {
        num: 'ধাপ ২',
        numEn: 'Step 2',
        title: isBn ? 'কোম্পানি প্রেরিত টেকনিশিয়ানের সরেজমিনে পরিদর্শন ও ভেরিফিকেশন' : 'Technical Inspection & Damage Verification',
        desc: isBn 
          ? 'কোম্পানি থেকে একজন নিয়োজিত টেকনিশিয়ান আপনার ছাদে পাঠানো হবে। তিনি মেকানিক্যাল ও ওয়াটেজ টেস্ট করে যাচাই করবেন এটি কোনো উৎপাদনগত ত্রুটি নাকি বাইরের হাত লেগে ফিজিক্যাল কোলাটেরাল ড্যামেজ।'
          : 'The brand manufacturer will dispatch an authorized field technician to your roof. They will measure the open-circuit voltage and check if the degradation is a manufacturing plate flaw or is caused by external interference.'
      },
      {
        num: 'ধাপ ৩',
        numEn: 'Step 3',
        title: isBn ? 'আবেদন দায়ের ও ক্লায়েন্ট টোকেন নম্বর ট্র্যাকিং সংগ্রহ' : 'Docket File Generation & Ticket ID Tracking',
        desc: isBn 
          ? 'পরিদর্শন শেষে টেকনিশিয়ানের রিপোর্টের ভিত্তিতে কাস্টমার ড্যাশবোর্ড থেকে একটি "Claim Docket Ticket" আইডি জেনারেট করে আপনাকে দেওয়া হবে। এই আইডি ব্যবহার করে যেকোনো সময় ট্র্যাকিং আপডেট নিতে পারবেন।'
          : 'Following inspection, a certified claims docket is officially logged. You will be provided with a unique "Warranty Claim Ticket ID" for tracking authorization updates online.'
      },
      {
        num: 'ধাপ ৪',
        numEn: 'Step 4',
        title: isBn ? 'মেরামত সম্পন্ন হওয়া অথবা ব্র্যান্ড নতুন প্যানেল রিপ্লেসমেন্ট' : 'Final Processing: Repair or Full Replacement',
        desc: isBn 
          ? 'যদি ল্যাব রিপোর্টে প্যানেলটি ত্রুটিযুক্ত সাব্যস্ত হয়, তবে ব্র্যান্ড প্যানেলটি বিনামূল্যে ঠিক করবে অথবা সমমানের একটি নতুন প্যানেল রিপ্লেস করে দেবে। তবে কোম্পানির প্রোটোকল অনুযায়ী পরিবহণ ও ক্রেন নিয়ে যাওয়ার লেবার চার্জ কাস্টমারকে দিতে হতে পারে।'
          : 'If verified as factory defect, the manufacturer ships a brand new backup panel or processes immediate free replacements. Note: as per corporate policy fine prints, ground transport or crane logistics cost might be borne by the client.'
      }
    ],

    sec3Title: isBn ? '⚠️ যে সকল কারণে ওয়ারেন্টি বাতিল (Void) হয়ে যেতে পারে' : '⚠️ Critical Factors That Can Void Your Warranty',
    sec3Desc: isBn 
      ? 'সতর্ক থাকুন! নিচের ভুলগুলোর কারণে আপনার সোলার ওয়ারেন্টির আইনি বৈধতা সঙ্গে সঙ্গে খারিজ হয়ে যেতে পারে:'
      : 'Be careful! Any of the following actions can instantly invalidate your solar panel equipment warranty:',

    voidReasons: [
      {
        title: isBn ? 'অননুমোদিত বা লোকাল মিস্ত্রি দিয়ে মেরামত' : 'Unauthorized Self or Local Repair',
        desc: isBn 
          ? 'কোম্পানির রেজিস্টার্ড টেকনিশিয়ান ছাড়া কোনো লোকাল ইলেকট্রিশিয়ান দিয়ে প্যানেলের পেছনের সিল খোলা বা ডায়োড বদলানোর চেষ্টা করলে।'
          : 'Opening the sealed junction box under panels, soldering diodes, or employing unauthorized local technicians to service hot-spots immediately voids terms.'
      },
      {
        title: isBn ? 'প্রাকৃতিক দুর্ঘটনাজনিত ক্ষতি বা বীমার বিষয়সমূহ' : 'Collateral Force Majeure or Physical Abuse',
        desc: isBn 
          ? 'ছাদে ভারী পাথর পড়ে কাচ ফেটে যাওয়া, ঝড়-তুফানে বড় গাছ ভেঙে প্যানেলের ওপর পড়া বা চুরি যাওয়া। মনে রাখবেন, এসব ক্ষতি সাধারণ কোম্পানি ওয়ারেন্টির মধ্যে পড়ে না, এগুলো হোম ইন্সুরেন্স বা বীমা পলিসি দিয়ে মেটাতে হয়।'
          : 'Panel shields broken by structural impact, heavy tree branch falls during cyclones, or external vandals. These are covered by solar insurance policies, NOT the standard product warranty.'
      },
      {
        title: isBn ? 'মারাত্মক নোংরা ও মেইনটেন্যান্সের চরম অবহেলা' : 'Extreme Neglect & Harsh Chemical Encrustation',
        desc: isBn 
          ? 'নিয়মিত প্যানেল পরিষ্কার না করে তার ওপর অতিরিক্ত লবণাক্ত লোনা স্তর, এসিড বা শক্ত ক্ষারীয় রাসায়নিক জমতে দিলে এবং গ্লাস নষ্ট হলে ক্লেইম রিজেক্ট করা হবে।'
          : 'Allowing layers of industrial acid rain, heavy sea sand crust, bird droppings, or using forbidden cleaning chemicals that eat away glass coatings blocks claims.'
      }
    ],
    verifiedDocuments: isBn ? 'ওয়ারেন্টি ক্লেইম ফাইল করার জন্য চমৎকার প্রস্তুতি!' : 'Outstanding preparations to lodge your warranty claim seamlessly!',
  };

  const completedDocsCount = Object.values(documentChecklist).filter(Boolean).length;
  const docsProgress = Math.round((completedDocsCount / Object.keys(documentChecklist).length) * 100);

  return (
    <div id="claim-panel" className="bg-[#FCFBF7] border border-amber-200/50 rounded-[2.5rem] p-6 md:p-10 shadow-xl max-w-5xl mx-auto space-y-10 text-left">
      
      {/* Top Banner section */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-6 border-b border-amber-100">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-100 text-amber-800 rounded-full text-xs font-black uppercase tracking-widest">
            <ShieldCheck className="w-3.5 h-3.5" />
            {isBn ? 'আইনি ও ক্লেইম গাইড' : 'Consumer Rights V2'}
          </div>
          <h2 className="text-3xl md:text-4xl font-black text-slate-900 tracking-tight leading-tight">
            {content.title}
          </h2>
          <p className="text-sm md:text-base font-medium text-gray-500 max-w-2xl">
            {content.subtitle}
          </p>
        </div>

        {/* 25 Year Badge */}
        <div className="flex items-center gap-4 bg-gradient-to-br from-indigo-500 to-indigo-700 text-white p-4 rounded-3xl shadow-lg shadow-indigo-100 self-stretch md:self-auto justify-center">
          <div className="text-left">
            <span className="text-[9px] font-black tracking-widest uppercase text-indigo-100 block">{isBn ? 'সর্বোচ্চ পাওয়ার গ্যারান্টি' : 'Power Output Guard'}</span>
            <span className="text-2xl font-extrabold leading-none">25 {isBn ? 'বছর' : 'Years'}</span>
          </div>
          <div className="w-9 h-9 bg-white/20 rounded-full flex items-center justify-center">
            <FileText className="w-5 h-5" />
          </div>
        </div>
      </div>

      <div className="p-5.5 bg-indigo-50/50 border border-indigo-100 rounded-2xl flex flex-col md:flex-row gap-6">
        <p className="text-sm md:text-base text-gray-700 font-semibold md:w-3/5 leading-relaxed self-center">
          {content.intro}
        </p>
        <div className="flex-1 space-y-2">
          <div className="p-3 bg-white rounded-xl border border-indigo-100 shadow-sm">
            <span className="text-xs font-black text-indigo-600 block mb-0.5">{content.warnP1}</span>
            <span className="text-xs text-gray-600 font-bold leading-relaxed">{content.warnD1}</span>
          </div>
          <div className="p-3 bg-white rounded-xl border border-indigo-100 shadow-sm">
            <span className="text-xs font-black text-indigo-600 block mb-0.5">{content.warnP2}</span>
            <span className="text-xs text-gray-600 font-bold leading-relaxed">{content.warnD2}</span>
          </div>
        </div>
      </div>

      {/* Interactive required document checklist */}
      <div className="bg-[#FFFDFB] border border-stone-200/50 rounded-3xl p-6 shadow-inner space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-amber-50 pb-4">
          <div>
            <h4 className="font-black text-slate-900 text-base">{content.sec1Title}</h4>
            <p className="text-xs text-gray-500 font-bold mt-1 uppercase tracking-wider">{content.sec1Sub}</p>
          </div>
          
          {/* Docs status badge */}
          <div className="bg-amber-50 border border-amber-200/60 rounded-2xl px-4 py-2 flex items-center gap-3 self-start md:self-auto">
            <div className="text-left">
              <span className="text-[8px] font-black text-amber-800 tracking-widest block uppercase">{isBn ? 'ডকুমেন্ট রেডি' : 'DOCS STATUS'}</span>
              <span className="text-sm font-black text-slate-800">{completedDocsCount} / {content.docs.length}</span>
            </div>
            <div className="w-12 h-2.5 bg-gray-200 rounded-full overflow-hidden">
              <div className="h-full bg-indigo-500 rounded-full transition-all duration-300" style={{ width: `${docsProgress}%` }} />
            </div>
          </div>
        </div>

        {/* List items mapping */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {content.docs.map((docItem) => (
            <div 
              key={docItem.id}
              onClick={() => toggleDoc(docItem.id)}
              className={`p-4.5 rounded-2xl border transition duration-150 cursor-pointer flex gap-3 text-left relative overflow-hidden bg-white ${
                documentChecklist[docItem.id] 
                  ? 'bg-indigo-50/50 border-indigo-300/60 ring-1 ring-indigo-300/40' 
                  : 'hover:bg-gray-50/50 border-stone-200/80'
              }`}
            >
              <div className="flex-shrink-0 pt-0.5">
                <CheckCircle 
                  className={`w-5.5 h-5.5 transition-transform duration-150 ${
                    documentChecklist[docItem.id] 
                      ? 'text-indigo-500 fill-indigo-100 scale-110' 
                      : 'text-gray-200'
                  }`} 
                />
              </div>
              <div className="space-y-1">
                <h5 className={`text-sm font-black transition-colors ${documentChecklist[docItem.id] ? 'text-indigo-950' : 'text-slate-800'}`}>
                  {docItem.title}
                </h5>
                <p className="text-xs text-gray-500 leading-relaxed font-semibold">
                  {docItem.desc}
                </p>
              </div>
            </div>
          ))}
        </div>

        {docsProgress === 100 && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }} 
            animate={{ opacity: 1, scale: 1 }}
            className="p-3.5 bg-emerald-500 text-white rounded-2xl font-black text-xs md:text-sm tracking-wide max-w-md mx-auto text-center shadow-lg shadow-emerald-100"
          >
            🎉 {content.verifiedDocuments}
          </motion.div>
        )}
      </div>

      {/* Accordion / Milestone style for Step-by-Step process */}
      <div className="space-y-5">
        <h3 className="text-lg font-black text-slate-800 flex items-center gap-2">
          <span className="w-2.5 h-5 rounded bg-indigo-500 inline-block" />
          {content.sec2Title}
        </h3>
        <p className="text-xs font-bold text-gray-400 uppercase tracking-widest pl-4 leading-none">{content.sec2Desc}</p>

        <div className="relative border-l-2 border-indigo-100 pl-6 ml-4 space-y-6 pt-2">
          {content.steps.map((step, idx) => {
            const isExpanded = expandedStep === idx;
            return (
              <div key={idx} className="relative group text-left">
                {/* Milestone Icon Bullet indicator */}
                <span 
                  onClick={() => setExpandedStep(isExpanded ? null : idx)}
                  className={`absolute -left-[35px] top-1.5 w-6.5 h-6.5 rounded-full flex items-center justify-center text-[10px] font-black cursor-pointer border shadow transition-all duration-300 ${
                    isExpanded 
                      ? 'bg-indigo-500 text-white border-indigo-600 scale-110 shadow-indigo-100' 
                      : 'bg-[#FCFBF7] text-slate-400 border-indigo-100 hover:border-indigo-300'
                  }`}
                >
                  {idx + 1}
                </span>

                <div 
                  onClick={() => setExpandedStep(isExpanded ? null : idx)}
                  className="bg-[#FCFBF7]/40 hover:bg-[#FCFBF7]/90 border border-stone-200/40 p-4.5 rounded-3xl cursor-pointer transition-all duration-200 flex items-start justify-between gap-4"
                >
                  <div className="space-y-1">
                    <span className="text-[10px] font-black tracking-widest uppercase text-indigo-500">
                      {isBn ? step.num : step.numEn}
                    </span>
                    <h4 className="text-base font-black text-slate-900 group-hover:text-indigo-600 transition-colors">
                      {step.title}
                    </h4>
                    
                    <AnimatePresence initial={false}>
                      {(isExpanded || idx === 0) && (
                        <motion.p
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="text-xs md:text-sm text-gray-600 leading-relaxed font-semibold pt-1.5 overflow-hidden"
                        >
                          {step.desc}
                        </motion.p>
                      )}
                    </AnimatePresence>
                  </div>

                  <ChevronDown 
                    className={`w-5 h-5 flex-shrink-0 text-gray-400 transition-transform duration-300 ${
                      isExpanded ? 'rotate-180' : ''
                    }`} 
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Avoid warrant void list */}
      <div className="bg-[#FFF5F5] border border-rose-100 rounded-[2.5rem] p-6 md:p-8 space-y-6">
        <div className="flex items-center gap-3 border-b border-rose-100 pb-4">
          <div className="p-2.5 bg-rose-100 text-rose-700 rounded-2xl">
            <AlertTriangle className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h4 className="font-black text-rose-950 text-base md:text-lg">{content.sec3Title}</h4>
            <p className="text-xs text-rose-700 font-extrabold uppercase mt-0.5 pl-0.5 tracking-wider">{content.sec3Desc}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {content.voidReasons.map((reason, idx) => (
            <div key={idx} className="bg-white/80 p-5 rounded-2xl border border-rose-100/50 space-y-2 shadow-sm text-left relative overflow-hidden">
              <div className="absolute right-3 top-3 w-4 h-4 text-rose-300 opacity-20">
                <Lock className="w-3.5 h-3.5" />
              </div>
              <span className="w-7 h-7 rounded-full bg-rose-50 text-rose-700 flex items-center justify-center text-xs font-black border border-rose-100">
                0{idx + 1}
              </span>
              <h5 className="font-extrabold text-rose-950 text-sm leading-snug">
                {reason.title}
              </h5>
              <p className="text-xs text-rose-900/75 leading-relaxed font-semibold">
                {reason.desc}
              </p>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}

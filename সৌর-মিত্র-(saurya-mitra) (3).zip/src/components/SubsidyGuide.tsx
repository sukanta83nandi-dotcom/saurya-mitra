import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BookOpen, CheckCircle2, ChevronRight, FileCheck, Coins, ChevronDown, HelpCircle, X } from 'lucide-react';
import Markdown from 'react-markdown';
import { Language, translations } from '../translations';
import { User } from 'firebase/auth';
import { LoginRequired } from './LoginRequired';

interface SubsidyGuideProps {
  language: Language;
  user: User | null;
  onLogin?: () => void;
}

export function SubsidyGuide({ language, user, onLogin }: SubsidyGuideProps) {
  const t = translations[language].subsidyGuide;
  const [activeFaqIdx, setActiveFaqIdx] = useState<number | null>(null);
  const [isFaqModalOpen, setIsFaqModalOpen] = useState(false);

  if (!user) {
    return <LoginRequired language={language} onLogin={onLogin} />;
  }

  const guideContent = `
${t.title}
${t.intro}

${t.subsidyTitle}
${t.subsidyItems.join('\n')}

${t.docsTitle}
${t.docsItems.join('\n')}

${t.stepsTitle}
${t.steps.join('\n')}
`;

  return (
    <div className="max-w-4xl mx-auto py-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {/* Amber Liquid Glass Card */}
        <motion.div
          whileHover={{ y: -6, scale: 1.025 }}
          className="p-7 bg-gradient-to-b from-amber-100/50 via-amber-50/40 to-amber-200/10 border-t-amber-100/80 border-l-amber-100/70 border-r-amber-300/40 border-b-amber-300/30 rounded-[2.2rem] text-center space-y-4 relative overflow-hidden backdrop-blur-2xl shadow-[0_20px_45px_-12px_rgba(217,119,6,0.12),inset_0_4px_16px_rgba(255,255,255,0.85),inset_0_-8px_24px_rgba(217,119,6,0.04)] select-none group"
        >
          {/* Specular Curved Gloss Reflection (Lens Flare / Glass boundary) */}
          <div className="absolute top-0 left-0 right-0 h-[45%] bg-gradient-to-b from-white/75 via-white/[0.04] to-transparent rounded-t-[2.2rem] pointer-events-none z-10" style={{ clipPath: 'ellipse(135% 70% at 50% 8%)' }} />

          {/* Sleek Dynamic Glass Sheen Sweep */}
          <motion.div 
            className="absolute inset-0 bg-gradient-to-r from-transparent via-white/22 to-transparent pointer-events-none z-10"
            style={{ skewX: -20 }}
            animate={{ x: ['-100%', '200%'] }}
            transition={{ repeat: Infinity, repeatDelay: 5, duration: 2.2, ease: "easeInOut" }}
          />

          {/* Hyper-realistic Glass Droplets */}
          <div className="absolute top-[12%] right-[10%] w-[11px] h-[11px] rounded-full border border-white/35 bg-white/10 pointer-events-none z-10 shadow-[1px_1.5px_2px_rgba(0,0,0,0.1),inset_1px_1.5px_2px_rgba(255,255,255,0.7),inset_-1px_-1.5px_2px_rgba(0,0,0,0.05)] backdrop-blur-[0.5px]">
            <div className="absolute top-[20%] left-[20%] w-[30%] h-[30%] rounded-full bg-white opacity-90" />
          </div>
          <div className="absolute bottom-[14%] left-[10%] w-[9px] h-[9px] rounded-full border border-white/35 bg-white/10 pointer-events-none z-10 shadow-[1px_1.5px_2px_rgba(0,0,0,0.1),inset_1px_1.5px_2px_rgba(255,255,255,0.7),inset_-1px_-1.5px_2px_rgba(0,0,0,0.05)] backdrop-blur-[0.5px]">
            <div className="absolute top-[20%] left-[20%] w-[30%] h-[30%] rounded-full bg-white opacity-90" />
          </div>

          <div className="relative z-10 space-y-3.5">
            <div className="w-12 h-12 bg-gradient-to-b from-white/90 to-amber-100/90 text-amber-600 rounded-2xl flex items-center justify-center mx-auto shadow-[0_8px_20px_-6px_rgba(217,119,6,0.25),inset_0_2px_4px_rgba(255,255,255,0.8)] border border-white">
              <Coins className="w-6 h-6" />
            </div>
            <h4 className="text-2xl font-black text-amber-950 tracking-tight leading-none">₹78,000</h4>
            <p className="text-[10px] text-amber-800/85 uppercase font-black tracking-widest">{t.statMaxSubsidy}</p>
          </div>
        </motion.div>

        {/* Blue Liquid Glass Card */}
        <motion.div
          whileHover={{ y: -6, scale: 1.025 }}
          className="p-7 bg-gradient-to-b from-blue-100/50 via-blue-50/40 to-blue-200/10 border-t-blue-100/80 border-l-blue-100/70 border-r-blue-300/40 border-b-blue-300/30 rounded-[2.2rem] text-center space-y-4 relative overflow-hidden backdrop-blur-2xl shadow-[0_20px_45px_-12px_rgba(37,99,235,0.12),inset_0_4px_16px_rgba(255,255,255,0.85),inset_0_-8px_24px_rgba(37,99,235,0.04)] select-none group"
        >
          {/* Specular Curved Gloss Reflection (Lens Flare / Glass boundary) */}
          <div className="absolute top-0 left-0 right-0 h-[45%] bg-gradient-to-b from-white/75 via-white/[0.04] to-transparent rounded-t-[2.2rem] pointer-events-none z-10" style={{ clipPath: 'ellipse(135% 70% at 50% 8%)' }} />

          {/* Sleek Dynamic Glass Sheen Sweep */}
          <motion.div 
            className="absolute inset-0 bg-gradient-to-r from-transparent via-white/22 to-transparent pointer-events-none z-10"
            style={{ skewX: -20 }}
            animate={{ x: ['-100%', '200%'] }}
            transition={{ repeat: Infinity, repeatDelay: 5.4, duration: 2.2, ease: "easeInOut" }}
          />

          {/* Hyper-realistic Glass Droplets */}
          <div className="absolute top-[12%] right-[10%] w-[11px] h-[11px] rounded-full border border-white/35 bg-white/10 pointer-events-none z-10 shadow-[1px_1.5px_2px_rgba(0,0,0,0.1),inset_1px_1.5px_2px_rgba(255,255,255,0.7),inset_-1px_-1.5px_2px_rgba(0,0,0,0.05)] backdrop-blur-[0.5px]">
            <div className="absolute top-[20%] left-[20%] w-[30%] h-[30%] rounded-full bg-white opacity-90" />
          </div>
          <div className="absolute bottom-[14%] left-[10%] w-[9px] h-[9px] rounded-full border border-white/35 bg-white/10 pointer-events-none z-10 shadow-[1px_1.5px_2px_rgba(0,0,0,0.1),inset_1px_1.5px_2px_rgba(255,255,255,0.7),inset_-1px_-1.5px_2px_rgba(0,0,0,0.05)] backdrop-blur-[0.5px]">
            <div className="absolute top-[20%] left-[20%] w-[30%] h-[30%] rounded-full bg-white opacity-90" />
          </div>

          <div className="relative z-10 space-y-3.5">
            <div className="w-12 h-12 bg-gradient-to-b from-white/90 to-blue-100/90 text-blue-600 rounded-2xl flex items-center justify-center mx-auto shadow-[0_8px_20px_-6px_rgba(37,99,235,0.25),inset_0_2px_4px_rgba(255,255,255,0.8)] border border-white">
              <FileCheck className="w-6 h-6" />
            </div>
            <h4 className="text-2xl font-black text-blue-950 tracking-tight leading-none">{t.stat3Doc}</h4>
            <p className="text-[10px] text-blue-800/85 uppercase font-black tracking-widest">{t.statEasyProcess}</p>
          </div>
        </motion.div>

        {/* Emerald Liquid Glass Card */}
        <motion.div
          whileHover={{ y: -6, scale: 1.025 }}
          className="p-7 bg-gradient-to-b from-emerald-100/50 via-emerald-50/40 to-emerald-200/10 border-t-emerald-100/80 border-l-emerald-100/70 border-r-emerald-300/40 border-b-emerald-300/30 rounded-[2.2rem] text-center space-y-4 relative overflow-hidden backdrop-blur-2xl shadow-[0_20px_45px_-12px_rgba(5,150,105,0.12),inset_0_4px_16px_rgba(255,255,255,0.85),inset_0_-8px_24px_rgba(5,150,105,0.04)] select-none group"
        >
          {/* Specular Curved Gloss Reflection (Lens Flare / Glass boundary) */}
          <div className="absolute top-0 left-0 right-0 h-[45%] bg-gradient-to-b from-white/75 via-white/[0.04] to-transparent rounded-t-[2.2rem] pointer-events-none z-10" style={{ clipPath: 'ellipse(135% 70% at 50% 8%)' }} />

          {/* Sleek Dynamic Glass Sheen Sweep */}
          <motion.div 
            className="absolute inset-0 bg-gradient-to-r from-transparent via-white/22 to-transparent pointer-events-none z-10"
            style={{ skewX: -20 }}
            animate={{ x: ['-100%', '200%'] }}
            transition={{ repeat: Infinity, repeatDelay: 5.8, duration: 2.2, ease: "easeInOut" }}
          />

          {/* Hyper-realistic Glass Droplets */}
          <div className="absolute top-[12%] right-[10%] w-[11px] h-[11px] rounded-full border border-white/35 bg-white/10 pointer-events-none z-10 shadow-[1px_1.5px_2px_rgba(0,0,0,0.1),inset_1px_1.5px_2px_rgba(255,255,255,0.7),inset_-1px_-1.5px_2px_rgba(0,0,0,0.05)] backdrop-blur-[0.5px]">
            <div className="absolute top-[20%] left-[20%] w-[30%] h-[30%] rounded-full bg-white opacity-90" />
          </div>
          <div className="absolute bottom-[14%] left-[10%] w-[9px] h-[9px] rounded-full border border-white/35 bg-white/10 pointer-events-none z-10 shadow-[1px_1.5px_2px_rgba(0,0,0,0.1),inset_1px_1.5px_2px_rgba(255,255,255,0.7),inset_-1px_-1.5px_2px_rgba(0,0,0,0.05)] backdrop-blur-[0.5px]">
            <div className="absolute top-[20%] left-[20%] w-[30%] h-[30%] rounded-full bg-white opacity-90" />
          </div>

          <div className="relative z-10 space-y-3.5">
            <div className="w-12 h-12 bg-gradient-to-b from-white/90 to-emerald-100/90 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto shadow-[0_8px_20px_-6px_rgba(5,150,105,0.25),inset_0_2px_4px_rgba(255,255,255,0.8)] border border-white">
              <BookOpen className="w-6 h-6" />
            </div>
            <h4 className="text-2xl font-black text-emerald-950 tracking-tight leading-none">{language === 'bn' ? '৩০০ ইউনিট' : '300 Units'}</h4>
            <p className="text-[10px] text-emerald-800/85 uppercase font-black tracking-widest">{t.statFreeGoal}</p>
          </div>
        </motion.div>
      </div>

      <div className="bg-white p-8 md:p-12 rounded-[2.5rem] shadow-sm border border-gray-100">
        <div className="prose prose-amber max-w-none 
          prose-headings:text-gray-900 prose-headings:font-bold 
          prose-p:text-gray-600 prose-p:leading-relaxed 
          prose-li:text-gray-600 markdown-body">
          <Markdown>{guideContent}</Markdown>
        </div>

        {/* FAQs popup trigger button */}
        {t.faqs && t.faqs.length > 0 && (
          <div className="border-t border-gray-100 pt-8 mt-10 flex flex-col items-center justify-center text-center">
            <motion.button
              onClick={() => setIsFaqModalOpen(true)}
              animate={{
                scale: [1, 1.02, 1],
                boxShadow: [
                  "0 0 0 0 rgba(245, 158, 11, 0.3), 0 4px 20px rgba(245,158,11,0.12)",
                  "0 0 0 12px rgba(245, 158, 11, 0), 0 8px 30px rgba(245,158,11,0.2)",
                  "0 0 0 0 rgba(245, 158, 11, 0), 0 4px 20px rgba(245,158,11,0.12)"
                ]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="inline-flex items-center gap-2.5 px-8 py-4 bg-amber-50 hover:bg-amber-100/90 text-amber-800 hover:text-amber-900 font-extrabold rounded-2xl border-2 border-amber-300/80 hover:border-amber-400 shadow-[0_4px_20px_rgba(245,158,11,0.12)] hover:shadow-[0_8px_30px_rgba(245,158,11,0.25)] transition-all duration-300 cursor-pointer"
            >
              <HelpCircle className="w-5 h-5 text-amber-600 animate-pulse shrink-0" />
              <span>{t.faqTitle || 'FAQs'}</span>
              <span className="ml-1 text-xs bg-amber-200/80 text-amber-950 px-2.5 py-0.5 rounded-full font-bold shrink-0">10 Q&As</span>
            </motion.button>
          </div>
        )}

        <div className="mt-12 p-8 bg-zinc-900 rounded-3xl text-white">
          <h4 className="text-xl font-bold mb-4">{t.ctaTitle}</h4>
          <p className="text-zinc-400 mb-6">{t.ctaDesc}</p>
          <div className="flex gap-4">
            <button className="px-6 py-3 bg-amber-400 text-black font-bold rounded-2xl hover:bg-amber-300 transition-colors flex items-center gap-2">
              {t.ctaButton} <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* FAQ Modal Popup */}
      <AnimatePresence>
        {isFaqModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsFaqModalOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm"
            />

            {/* Modal Box */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
              transition={{ type: "spring", duration: 0.5 }}
              className="bg-white rounded-[2.5rem] w-full max-w-4xl max-h-[85vh] flex flex-col overflow-hidden shadow-2xl relative z-10 border border-gray-100"
            >
              {/* Header */}
              <div className="p-6 md:p-8 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-amber-100 text-amber-700 rounded-2xl flex items-center justify-center shrink-0">
                    <HelpCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-xl md:text-2xl font-black text-gray-900 tracking-tight leading-tight">
                      {t.faqTitle || 'Frequently Asked Questions'}
                    </h3>
                    <p className="text-xs md:text-sm text-gray-500 font-medium">
                      {language === 'bn' ? 'সৌর মিত্র সাবসিডি এবং প্রসেস গাইড' : 'Saurya Mitra Subsidy & Process Guide'}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setIsFaqModalOpen(false)}
                  className="p-2.5 bg-gray-100 hover:bg-gray-200 text-gray-500 hover:text-gray-800 rounded-full transition-colors cursor-pointer shrink-0"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Body (Scrollable Accordions) */}
              <div className="p-6 md:p-8 overflow-y-auto space-y-4 max-h-[calc(85vh-150px)]">
                {t.faqs.map((faq: any, idx: number) => {
                  const isOpen = activeFaqIdx === idx;
                  return (
                    <div 
                      key={idx}
                      className={`border border-gray-150 md:border-gray-100 rounded-2xl overflow-hidden transition-all duration-300 ${isOpen ? 'bg-amber-50/40 border-amber-150 shadow-sm' : 'bg-gray-50/30 hover:bg-gray-50'}`}
                    >
                      <button
                        onClick={() => setActiveFaqIdx(isOpen ? null : idx)}
                        className="w-full text-left px-5 py-4 md:px-6 flex justify-between items-center gap-4 font-bold text-gray-900 text-sm md:text-base cursor-pointer select-none"
                      >
                        <span className="leading-snug">{faq.q}</span>
                        <motion.div
                          animate={{ rotate: isOpen ? 180 : 0 }}
                          transition={{ duration: 0.2 }}
                          className={`p-1.5 rounded-full shrink-0 ${isOpen ? 'bg-amber-100 text-amber-700' : 'bg-gray-200/50 text-gray-500'}`}
                        >
                          <ChevronDown className="w-4 h-4" />
                        </motion.div>
                      </button>
                      <AnimatePresence initial={false}>
                        {isOpen && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.25, ease: "easeInOut" }}
                          >
                            <div className="px-5 pb-5 pt-2 md:px-6 text-sm text-gray-600 leading-relaxed border-t border-gray-150 md:border-gray-100">
                              {faq.a}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                })}
              </div>

              {/* Footer */}
              <div className="p-4 md:p-6 border-t border-gray-100 bg-gray-50/50 text-center text-xs text-gray-400 font-medium">
                {language === 'bn' 
                  ? 'যেকোনো অতিরিক্ত তথ্যের জন্য আপনার নির্বাচিত সোলার ভেন্ডরের সঙ্গে যোগাযোগ করতে পারেন।' 
                  : 'For any additional information, please connect with your selected solar vendor.'}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

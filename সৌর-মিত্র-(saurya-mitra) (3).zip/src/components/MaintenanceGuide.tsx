import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Spade, 
  Wrench, 
  Droplet, 
  Sun, 
  Zap, 
  Cpu, 
  Activity, 
  ShieldCheck, 
  TrendingUp, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  Coins, 
  Info,
  RotateCcw,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Calendar,
  Printer,
  FileDown
} from 'lucide-react';
import { Language } from '../translations';
import { cn } from '../lib/utils';

interface MaintenanceGuideProps {
  language: Language;
  user?: any;
  userProfile?: any;
}

export function MaintenanceGuide({ language, user, userProfile }: MaintenanceGuideProps) {
  const [activeCard, setActiveCard] = useState<number | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    try {
      const d = new Date();
      const offset = d.getTimezoneOffset();
      const local = new Date(d.getTime() - (offset * 60 * 1000));
      return local.toISOString().split('T')[0];
    } catch {
      return '2026-05-28';
    }
  });

  const [history, setHistory] = useState<Record<string, Record<string, { checked: boolean; timestamp: string }>>>(() => {
    try {
      const saved = localStorage.getItem('sauryamitra_maintenance_history');
      return saved ? JSON.parse(saved) : {};
    } catch (e) {
      console.error('Error loading history:', e);
      return {};
    }
  });

  const [rescheduleDateId, setRescheduleDateId] = useState<string | null>(null);
  const [tempNewDate, setTempNewDate] = useState<string>('');
  const [expandedHistory, setExpandedHistory] = useState<Record<string, boolean>>({});

  const [showCalendar, setShowCalendar] = useState(false);
  const [calendarViewDate, setCalendarViewDate] = useState<Date>(() => {
    return new Date();
  });

  const todayStr = useMemo(() => {
    try {
      const d = new Date();
      const offset = d.getTimezoneOffset();
      const local = new Date(d.getTime() - (offset * 60 * 1000));
      return local.toISOString().split('T')[0];
    } catch {
      return '2026-05-28';
    }
  }, []);

  const uncompletedFutureDates = useMemo(() => {
    return Object.keys(history)
      .filter(dStr => {
        const isFuture = dStr > todayStr;
        const taskRun = history[dStr] || {};
        const completedCount = Object.values(taskRun).filter(t => t.checked).length;
        const isCompleted = completedCount === 7;
        return isFuture && !isCompleted;
      })
      .sort();
  }, [history, todayStr]);

  const nearestUpcomingDate = useMemo(() => {
    return uncompletedFutureDates[0] || null;
  }, [uncompletedFutureDates]);

  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (year: number, month: number) => {
    const day = new Date(year, month, 1).getDay();
    return day === 0 ? 6 : day - 1;
  };

  const monthNamesEn = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const monthNamesBn = [
    'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
    'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
  ];

  const getMonthName = (date: Date) => {
    const m = date.getMonth();
    return isBn ? monthNamesBn[m] : monthNamesEn[m];
  };

  const handlePrevMonth = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCalendarViewDate(prev => {
      const year = prev.getFullYear();
      const month = prev.getMonth();
      const newMonth = month === 0 ? 11 : month - 1;
      const newYear = month === 0 ? year - 1 : year;
      return new Date(newYear, newMonth, 1);
    });
  };

  const handleNextMonth = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCalendarViewDate(prev => {
      const year = prev.getFullYear();
      const month = prev.getMonth();
      const newMonth = month === 11 ? 0 : month + 1;
      const newYear = month === 11 ? year + 1 : year;
      return new Date(newYear, newMonth, 1);
    });
  };

  const handleDaySelect = (dayStr: string) => {
    handleDateChange(dayStr);
    setShowCalendar(false);
  };

  const handleClear = (e: React.MouseEvent) => {
    e.stopPropagation();
    handleDateChange(todayStr);
    setCalendarViewDate(new Date());
    setShowCalendar(false);
  };

  const handleTodayClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    handleDateChange(todayStr);
    setCalendarViewDate(new Date());
    setShowCalendar(false);
  };

  const formatToMMDDYYYY = (dateStr: string) => {
    if (!dateStr) return '';
    const parts = dateStr.split('-');
    if (parts.length !== 3) return dateStr;
    return `${parts[1]}-${parts[2]}-${parts[0]}`;
  };

  const activeChecklist = useMemo(() => {
    return history[selectedDate] || {};
  }, [history, selectedDate]);

  const [showResetModal, setShowResetModal] = useState(false);
  const [resetOption, setResetOption] = useState<'history' | 'upcoming' | 'all'>('history');

  const confirmResetHistory = () => {
    setHistory(prev => {
      const copy = { ...prev };
      if (resetOption === 'history') {
        Object.keys(copy).forEach(dateStr => {
          if (dateStr <= todayStr) {
            delete copy[dateStr];
          }
        });
      } else if (resetOption === 'upcoming') {
        Object.keys(copy).forEach(dateStr => {
          if (dateStr > todayStr) {
            delete copy[dateStr];
          }
        });
      } else if (resetOption === 'all') {
        try {
          localStorage.removeItem('sauryamitra_maintenance_history');
        } catch (e) {
          console.error('Error clearing storage:', e);
        }
        return {};
      }

      try {
        localStorage.setItem('sauryamitra_maintenance_history', JSON.stringify(copy));
      } catch (e) {
        console.error('Error saving history on reset:', e);
      }
      return copy;
    });

    if (resetOption === 'all') {
      setSelectedDate(todayStr);
    } else if (resetOption === 'upcoming' && selectedDate > todayStr) {
      setSelectedDate(todayStr);
    } else if (resetOption === 'history' && selectedDate <= todayStr) {
      setSelectedDate(todayStr);
    }

    setShowResetModal(false);
  };

  const handleDateChange = (dateVal: string) => {
    setSelectedDate(dateVal);
    if (dateVal && dateVal > todayStr) {
      if (!history[dateVal]) {
        setHistory(prev => {
          const updated = {
            ...prev,
            [dateVal]: {}
          };
          try {
            localStorage.setItem('sauryamitra_maintenance_history', JSON.stringify(updated));
          } catch (e) {
            console.error('Error saving history on future date select:', e);
          }
          return updated;
        });
      }
    }
  };

  const rescheduleTask = (oldDate: string, newDate: string) => {
    if (!newDate || oldDate === newDate) return;
    setHistory(prev => {
      const copy = { ...prev };
      copy[newDate] = copy[oldDate] || {};
      delete copy[oldDate];
      try {
        localStorage.setItem('sauryamitra_maintenance_history', JSON.stringify(copy));
      } catch (e) {
        console.error('Error saving rescheduled history:', e);
      }
      return copy;
    });
    if (selectedDate === oldDate) {
      setSelectedDate(newDate);
    }
  };

  const upcomingDates = useMemo(() => {
    return Object.keys(history).filter(dateStr => dateStr > todayStr).sort();
  }, [history, todayStr]);

  const pastDates = useMemo(() => {
    return Object.keys(history).filter(dateStr => dateStr <= todayStr).sort().reverse();
  }, [history, todayStr]);

  const isBn = language === 'bn';

  // Translate labels
  const content = {
    title: isBn ? 'সোলার প্যানেলের রক্ষণাবেক্ষণ ও পরিচর্যা' : 'Solar Panel Maintenance & Care',
    subtitle: isBn 
      ? 'আপনাদের সোলার সিস্টেম দীর্ঘস্থায়ী এবং ২০-৩০% বেশি কার্যক্ষম রাখার সহজ নির্দেশিকা' 
      : 'Simple guidelines to keep your solar system long-lasting and operating 20-30% more efficiently',
    intro: isBn
      ? 'সোলার প্যানেলের রক্ষণাবেক্ষণ বা মেইনটেন্যান্স খুব জটিল কিছু নয়, কিন্তু নিয়মিত করাটা অত্যন্ত জরুরি। বিশেষ করে পশ্চিমবঙ্গের ধুলোবালি এবং আর্দ্রতাযুক্ত জলবায়ুতে সঠিক পরিচর্যা না করলে প্যানেলের কার্যকারিতা ব্যাপক হ্রাস পেতে পারে। নিচে ধাপে ধাপে সম্পূর্ণ গাইডটি দেওয়া হলো:'
      : 'Solar panel maintenance is not complex, but regular care is absolutely vital. Especially in West Bengal\'s dusty and humid climate, neglect can reduce efficiency by 20-30%. Below is a complete step-by-step guide:',
    
    sec1Title: isBn ? '১. প্যানেল পরিষ্কার করার প্রক্রিয়া' : '1. Panel Cleaning Process',
    sec1Sub: isBn ? 'সবচেয়ে গুরুত্বপূর্ণ ও নিয়মিত কাজ' : 'The most critical & regular task',
    
    cleaningPoints: [
      {
        icon: Clock,
        iconColor: 'text-amber-500',
        borderColor: 'border-amber-100',
        bgColor: 'bg-amber-50/50',
        title: isBn ? 'পর্যাপ্ত সময় নির্বাচন' : 'Ideal Timing',
        desc: isBn 
          ? 'সবসময় ভোরবেলা বা সন্ধ্যার আগে পরিষ্কার করবেন। প্যানেল যখন কড়া রোদে গরম থাকে, তখন হঠাৎ ঠান্ডা জল দিলে কাচ ফেটে যেতে পারে (Thermal Shock)।'
          : 'Always clean early in the morning or late in the evening. Spraying cold water on panels heated by intense sunlight can crack the glass (Thermal Shock).',
      },
      {
        icon: Droplet,
        iconColor: 'text-blue-500',
        borderColor: 'border-blue-100',
        bgColor: 'bg-blue-50/50',
        title: isBn ? 'সদুপযোগী জলের গুণমান' : 'Water Quality',
        desc: isBn 
          ? 'পরিষ্কার মৃদু জল (Soft Water) ব্যবহার করুন। আয়রনযুক্ত বা কড়া ক্ষারীয় জল ব্যবহার করলে প্যানেলে স্থায়ী সাদা ছোপ পড়ে যায়, যা পরে রোদ আটকাতে শুরু করে।'
          : 'Use clean, soft water. Avoid iron-rich or hard water, as they deposit sticky white scale marks that permanently block sunlight.',
      },
      {
        icon: Spade,
        iconColor: 'text-emerald-500',
        borderColor: 'border-emerald-100',
        bgColor: 'bg-emerald-50/50',
        title: isBn ? 'পরিষ্কার করার সঠিক পদ্ধতি' : 'Gentle Cleaning Tools',
        desc: isBn 
          ? 'নরম স্পঞ্জ বা মাইক্রোফাইবার যুক্ত লাঠিওয়ালা ওয়াইপার ব্যবহার করুন। কোনোভাবেই স্ক্র্যাচ ফেলে এমন স্ক্রাবার বা শক্ত ব্রাশ ব্যবহার করবেন না।'
          : 'Use a soft sponge, squeeze wiper, or microfibre cloth. Never use harsh scrubbers or hard wire brushes, which can scratch the glass surface.',
      },
      {
        icon: Activity,
        iconColor: 'text-indigo-500',
        borderColor: 'border-indigo-100',
        bgColor: 'bg-indigo-50/50',
        title: isBn ? 'পরিষ্কার করার ফ্রিকোয়েন্সি' : 'Frequency of Cleaning',
        desc: isBn 
          ? 'পশ্চিমবঙ্গে মাসে অন্তত ২ বার পরিষ্কার করা ভালো। আপনার বাড়ি যদি ব্যস্ত রাস্তার পাশে হয়, তবে সপ্তাহে একবার করা প্রয়োজন।'
          : 'In West Bengal, cleaning twice a month is ideal. If your home is next to a heavy-traffic main road, cleaning once a week is highly recommended.',
      }
    ],

    sec2Title: isBn ? '২. ইনভার্টার ও কন্ট্রোলার পরিচর্যা' : '2. Inverter & Controller Maintenance',
    sec2Sub: isBn ? 'সিস্টেমের মস্তিষ্ককে সচল রাখুন' : 'Keep the brain of your system healthy',
    sec2Desc: isBn 
      ? 'ইনভার্টার হলো আপনার সোলার সিস্টেমের প্রধান পরিচালনা কেন্দ্র। এটি ঠিকমতো কাজ না করলে সম্পূর্ণ বিদ্যুৎ উৎপাদন ব্যাহত হবে।'
      : 'The inverter is the central intelligence of your solar power array. If it functions poorly, total power output immediately drops to zero.',

    inversionPoints: [
      {
        title: isBn ? 'ডিসপ্লে মনিটরিং ও কোড চেক' : 'Display & Error Code Monitoring',
        desc: isBn 
          ? 'ইনভার্টারের ডিজিটাল ডিসপ্লেতে কোনো লাল বাতি বা "Error Code" ভেসে উঠছে কি না তা নিয়মিত খেয়াল করুন এবং রিপোর্ট রাখুন।'
          : 'Regularly glance at the digital screen to verify there are no active fault indicators, blinking red signals, or error numbers.'
      },
      {
        title: isBn ? 'পর্যাপ্ত ভেন্টিলেশন ও শীতলীকরণ' : 'Ventilation & Airflow Space',
        desc: isBn 
          ? 'ইনভার্টারটি যেখানে বসানো হয়েছে সেখানে বাতাস চলাচলের পর্যাপ্ত ফাঁকা জায়গা নিশ্চিত করুন। ধুলোবালি জমে কুলিং ফ্যান বন্ধ হলে ডিভাইস গরম হয়ে বন্ধ হতে পারে।'
          : 'Ensure the inverter is placed in a cool, well-ventilated space. Dust blocking the heat vents or cooling fan can trigger automatic high-temp shutdown.'
      },
      {
        title: isBn ? 'ইন্ডিকেটর লাইটের সংকেত বোঝা' : 'Reading Indicator Lights Status',
        desc: isBn 
          ? 'সবুজ এলইডি বাতি মানে সিস্টেম জেনারেশন পুরোপুরি ঠিক আছে। হলুদ/কমলা বাতি সতর্কবার্তা দেয় এবং লাল বাতি গভীর সমস্যা নির্দেশ করে।'
          : 'Constant solid green LED indicates generation is fully synchronized. Orange/yellow signals a warning, while solid red alerts you of a trip or fault.'
      }
    ],

    sec3Title: isBn ? '৩. ইলেকট্রিক্যাল কানেকশন ও ওয়্যারিং' : '3. Electrical Wiring & Connection Check',
    sec3Desc: isBn 
      ? 'তারের জোড়গুলো কোথাও লুজ হয়ে গেছে কি না বা ইঁদুরের কামড়ে ক্ষতিগ্রস্ত হয়েছে কি না তা নিয়মিত পরখ করা উচিত। জাংশন বক্সের ভেতরে কোনো পোড়া স্পট বা মাকড়সার ঝুল জমতে দেওয়া যাবে না।'
      : 'Inspect standard cabling paths to identify loose joints or rodent-bitten lines. Keep outer junction boxes free of carbon deposits, moisture ingress, or spider webs.',

    sec4Title: isBn ? '৪. মেটাল স্ট্রাকচার ও মাউন্টিং ইন্টিগ্রিটি' : '4. Rigid Metal Structure & Mounting Frame',
    sec4Desc: isBn 
      ? 'প্যানেলগুলো যে লোহা বা গ্যালভানাইজড অ্যালুমিনিয়াম স্ট্রাকচারের ওপর বসে আছে, সেগুলোতে মরচে ধরছে কি না বা নাট-বোল্ট আলগা হয়েছে কি না বছরে অন্তত একবার খতিয়ে দেখুন। বিশেষ করে পশ্চিমবঙ্গের গ্রীষ্মকালীন কালবৈশাখী ঝড় ও বর্ষার পূর্বে এই পরীক্ষাটি করা অত্যন্ত জুরুরি।'
      : 'Examine the structural hot-dip galvanized steel or aluminium mounting frames for rust, metal fatigue, or loose fasteners at least safely once a year. Doing this before the heavy summer Kalbaishakhi storms is highly critical in West Bengal.',

    sec5Title: isBn ? '৫. রক্ষণাবেক্ষণের আনুমানিক খরচ (ভারত - ২০২৬)' : '5. Estimated AMC Maintenance Costs (India - 2026)',
    sec5Desc: isBn 
      ? 'আপনার যদি নিজে সোলার প্যানেল পরিষ্কার বা পরিচর্যা করার সময় বা সুযোগ না থাকে, তবে স্থানীয় রেজিস্টার্ড ভেন্ডরদের থেকে বার্ষিক রক্ষণাবেক্ষণ চুক্তি বা AMC (Annual Maintenance Contract) নিতে পারেন:'
      : 'If you lack the specialized equipment, time, or confidence to clean or service the panels yourself, registered solar vendors offer professional Annual Maintenance Contracts (AMC) in West Bengal:',

    tableCols: {
      size: isBn ? 'সিস্টেম সাইজ' : 'System Size',
      cost: isBn ? 'আনুমানিক বার্ষিক খরচ (AMC)' : 'Avg. Annual AMC Cost',
      benefits: isBn ? 'সেবা ও সুবিধাসমূহ' : 'Key Inclusions'
    },

    tableRows: [
      {
        size: '1 - 3 kW',
        cost: '₹1,800 - ₹3,000',
        benefits: isBn ? 'বছরে ৪ থেকে ৬ বার প্রফেশনাল ওয়াশ, তারের জোড় ও ইনভার্টার হেলথ চেকআপ।' : '4 to 6 professional water washes per year, full voltage diagnostics & inverter load-run testing.'
      },
      {
        size: '3 - 5 kW',
        cost: '₹3,000 - ₹6,000',
        benefits: isBn ? 'প্রতি মাসে বা ৪৫ দিন অন্তর মেকানিক্যাল ক্লিনিং, থার্মাল ইমেজিং এবং আর্টিং রেজিস্ট্যান্স পরিমাপ।' : 'Professional high-pressure foam/RO water cleaning, thermal hot-spot check & earthing resistance test.'
      }
    ],

    proTipTitle: isBn ? 'স্মার্ট প্রো-টিপ (Pro-Tip):' : 'Smart Pro-Tip:',
    proTipDesc: isBn 
      ? 'যদিও বর্ষার জল প্যানেল উপর থেকে ময়লা ধুয়ে ফেলে সাময়িক আরাম দেয়, কিন্তু বর্ষার ঘন কাদার ফোঁটা শুকিয়ে এক স্তর শুকনো আস্তরণ তৈরি করে। তাই বর্ষা শেষ হওয়ার সাথে সাথেই একটি পুঙ্খানুপুঙ্খ পরিষ্কার সার্ভিস করানো অত্যন্ত বুদ্ধিমানের কাজ হবে।'
      : 'While heavy monsoon rain successfully washes away surface dust, mud splashes dry into stubborn solar-blocking layers on dry days. Scheduling a deep, soft detergent clean-up right after the autumn clearing maximizes winter generation.',

    checklistTitle: isBn ? 'ইন্টারেক্টিভ রক্ষণাবেক্ষণ চেকলিস্ট' : 'Interactive Maintenance Tracker Checklist',
    checklistSubtitle: isBn 
      ? 'আপনার সোলার প্ল্যান্টের নিয়মিত সুরক্ষার জন্য টিক দিয়ে ট্র্যাক করুন' 
      : 'Check off items as you perform your regular residential solar wellness inspect',

    checklistItems: [
      { id: 'cleanTime', text: isBn ? 'সূর্যের আলো তীব্র হওয়ার আগে ভোরে বা সূর্যাস্তের পর প্যানেল পরিষ্কার করা হয়েছে?' : 'Cleaned early morning or after sunset (preventing thermal shock)?' },
      { id: 'cleanWater', text: isBn ? 'আয়রনমুক্ত মিষ্টি মৃদু জল ব্যবহার করা হয়েছে?' : 'Used iron-free soft water for pressure washing?' },
      { id: 'cleanMethod', text: isBn ? 'স্ক্র্যাপার ও শক্ত ঝাড়ু বর্জন করে নরম সুতির কাপড় বা স্পঞ্জ ব্যবহার করা হয়েছে?' : 'Used only soft sponges/microfibre cloths without wire scrubbers?' },
      { id: 'invDisplay', text: isBn ? 'ইনভার্টারের ডিজিটাল স্ক্রিনের প্যারামিটার ও কোনো ফল্ট কোড চেক করা হয়েছে?' : 'Inspected inverter load parameters and ensured no active red warning codes?' },
      { id: 'invVent', text: isBn ? 'ইনভার্টারের ভেতরের ফ্যান এবং কেবিনের চারপাশে বাতাস চলাচলের পথ ক্লিয়ার রাখা হয়েছে?' : 'Cleaned dust around inverter heatsinks and verified clear airflow gap?' },
      { id: 'wireCheck', text: isBn ? 'তারের পাইপ বা ক্যাবলগুলো অক্ষত আছে এবং কোনো খোলা অংশ নেই তো?' : 'Verified DC/AC conduits are firm and free from rodent or weather damages?' },
      { id: 'strucCheck', text: isBn ? 'মাউন্ট করা লোহার অ্যাঙ্গেল ও নাট-বোল্ট মজবুত আছে কিনা পরীক্ষা করেছেন?' : 'Inspected structure bolts and earthing connections for extreme winds?' }
    ],
    verifiedMsg: isBn ? 'আপনার প্ল্যান্ট সম্পূর্ণ সুরক্ষিত ও সর্বোচ্চ দক্ষতায় চলছে!' : 'Excellent! Your plant is fully optimized for maximum eco-efficiency!'
  };

  const toggleCheck = async (key: string) => {
    const isChecked = activeChecklist[key]?.checked || false;
    const newChecked = !isChecked;
    
    const now = new Date();
    const timestampStr = now.toLocaleTimeString(language === 'bn' ? 'bn-BD' : 'en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });

    const updatedHistory = {
      ...history,
      [selectedDate]: {
        ...(history[selectedDate] || {}),
        [key]: {
          checked: newChecked,
          timestamp: timestampStr
        }
      }
    };

    setHistory(updatedHistory);
    try {
      localStorage.setItem('sauryamitra_maintenance_history', JSON.stringify(updatedHistory));
    } catch (e) {
      console.error('Error saving history to localStorage:', e);
    }

    // Resolve User_ID
    const userId = userProfile?.sheetUserId || userProfile?.email || user?.uid || user?.email || 'guest';

    // Post to spreadsheet pipeline
    try {
      const response = await fetch('/api/maintenance-log', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userId,
          logDate: selectedDate,
          taskId: key,
          statusChecked: newChecked ? 1 : 0,
          timestamp: now.toISOString()
        })
      });
      const resData = await response.json();
      console.log('Spreadsheet dynamic log sync response:', resData);
    } catch (err) {
      console.error('Failed to post checklist sync event:', err);
    }
  };

  const handleDownloadReport = () => {
    // Premium document generator
    const timestamp = new Date().toLocaleString(language === 'bn' ? 'bn-BD' : 'en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });

    const upcomingDatesHtml = upcomingDates.length === 0 ? `
      <div class="empty-state">
        ${isBn ? 'কোনো রক্ষণাবেক্ষণের সময়সূচী নির্ধারিত নেই। এটি সেট করতে ক্যালেন্ডারে ভবিষ্যতের তারিখ নির্বাচন করুন।' : 'No pending maintenance runs scheduled. Select a future date from the date picker to add one.'}
      </div>
    ` : upcomingDates.map(dateStr => {
      const dateTasks = history[dateStr] || {};
      const completed = Object.values(dateTasks).filter(t => t.checked).length;
      const total = content.checklistItems.length;
      
      const itemsHtml = content.checklistItems.map(item => {
        const isChecked = dateTasks[item.id]?.checked || false;
        return `
          <div class="task-item ${isChecked ? 'checked' : ''}">
            <span class="task-check" style="color: ${isChecked ? '#10b981' : '#cbd5e1'}">${isChecked ? '✓' : '○'}</span>
            <span>${item.text}</span>
          </div>
        `;
      }).join('');

      return `
        <div class="card bg-amber-50-print">
          <div class="card-header">
            <span class="card-date">📅 ${dateStr}</span>
            <div style="display: flex; gap: 4px; align-items: center;">
              <span class="badge badge-pending">${isBn ? 'পেন্ডিং' : 'PENDING'}</span>
              <span class="card-count">${completed}/${total} ${isBn ? 'সম্পন্ন' : 'checked'}</span>
            </div>
          </div>
          <div class="task-list">
            ${itemsHtml}
          </div>
        </div>
      `;
    }).join('');

    const pastDatesHtml = pastDates.length === 0 ? `
      <div class="empty-state">
        ${isBn ? 'কোনো অতীত মেইনটেন্যান্স রেকর্ড সচল পাওয়া যায়নি।' : 'No past logs recorded yet.'}
      </div>
    ` : pastDates.map(dateStr => {
      const dateTasks = history[dateStr] || {};
      const completed = Object.values(dateTasks).filter(t => t.checked).length;
      const total = content.checklistItems.length;
      const isAllCompleted = completed === total && total > 0;
      
      const itemsHtml = content.checklistItems.map(item => {
        const isChecked = dateTasks[item.id]?.checked || false;
        const timeVal = dateTasks[item.id]?.timestamp ? ` (${dateTasks[item.id].timestamp})` : '';
        return `
          <div class="task-item ${isChecked ? 'checked' : ''}">
            <span class="task-check" style="color: ${isChecked ? '#10b981' : '#cbd5e1'}">${isChecked ? '✓' : '○'}</span>
            <span class="${!isChecked ? 'inactive-task' : ''}">${item.text}${isChecked && timeVal ? `<span class="task-time">${timeVal}</span>` : ''}</span>
          </div>
        `;
      }).join('');

      return `
        <div class="card ${isAllCompleted ? 'bg-emerald-50-print' : 'bg-slate-55-print'}">
          <div class="card-header">
            <span class="card-date">📅 ${dateStr}</span>
            <div style="display: flex; gap: 4px; align-items: center;">
              <span class="badge ${isAllCompleted ? 'badge-completed' : 'badge-partial'}">
                ${isAllCompleted ? (isBn ? 'সম্পূর্ণ' : 'COMPLETED') : (isBn ? 'আংশিক' : 'PARTIAL')}
              </span>
              <span class="card-count">${completed}/${total} ${isBn ? 'সম্পন্ন' : 'checked'}</span>
            </div>
          </div>
          <div class="task-list">
            ${itemsHtml}
          </div>
        </div>
      `;
    }).join('');

    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>${isBn ? 'রক্ষণাবেক্ষণ রিপোর্ট - সৌর মিত্র' : 'Saurya Mitra Maintenance Report'}</title>
        <style>
          @page {
            size: A4 portrait;
            margin: 8mm 10mm 8mm 10mm;
          }
          body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            color: #1e293b;
            margin: 0;
            padding: 0;
            line-height: 1.35;
            font-size: 11px;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
          .watermark {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 400px;
            height: 400px;
            opacity: 0.20;
            z-index: 9999;
            pointer-events: none;
          }
          .header {
            border-bottom: 2.5px solid #2c7a7b;
            padding-bottom: 10px;
            margin-bottom: 12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
          }
          .header-left {
            display: flex;
            align-items: center;
            gap: 12px;
          }
          .header-logo {
            height: 35px;
            width: auto;
            object-fit: contain;
          }
          .header-titles {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
          }
          .logo-text {
            font-size: 20px;
            font-weight: 800;
            color: #0f766e;
            letter-spacing: -0.02em;
            line-height: 1.2;
            margin: 0;
          }
          .tagline {
            font-size: 11px;
            color: #64748b;
            font-weight: 600;
            margin-top: 1px;
            line-height: 1.2;
          }
          .timestamp {
            font-size: 10px;
            color: #64748b;
            text-align: right;
            line-height: 1.3;
          }
          h2.report-title {
            font-size: 14.5px;
            margin: 0 0 12px 0;
            color: #0f172a;
            text-align: center;
            font-weight: 850;
            text-transform: uppercase;
            letter-spacing: 0.025em;
          }
          .sections-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            align-items: start;
          }
          .section {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            padding: 10px 12px;
            box-sizing: border-box;
          }
          .section-title {
            font-size: 10.5px;
            color: #0f766e;
            font-weight: 800;
            border-bottom: 2px solid #cbd5e1;
            padding-bottom: 5px;
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            display: flex;
            align-items: center;
            gap: 4px;
          }
          .card {
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 7px 9px;
            margin-bottom: 7px;
            page-break-inside: avoid;
          }
          .bg-amber-50-print {
            border-left: 3px solid #f59e0b;
          }
          .bg-emerald-50-print {
            border-left: 3px solid #10b981;
          }
          .bg-slate-55-print {
            border-left: 3px solid #94a3b8;
          }
          .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-weight: bold;
            margin-bottom: 5px;
          }
          .card-date {
            font-family: monospace;
            font-size: 10.5px;
            color: #1e293b;
          }
          .card-count {
            font-size: 9px;
            color: #64748b;
            font-weight: 700;
          }
          .badge {
            font-size: 8px;
            padding: 1px 4px;
            border-radius: 4px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.025em;
          }
          .badge-pending {
            background-color: #fef9c3;
            color: #854d0e;
          }
          .badge-completed {
            background-color: #dcfce7;
            color: #14532d;
          }
          .badge-partial {
            background-color: #fef3c7;
            color: #78350f;
          }
          .task-list {
            font-size: 9px;
            border-top: 1px dashed #f1f5f9;
            padding-top: 5px;
          }
          .task-item {
            display: flex;
            align-items: flex-start;
            gap: 4px;
            margin-bottom: 2.5px;
            color: #334155;
          }
          .task-item.checked {
            color: #0f765e;
            font-weight: 600;
          }
          .task-check {
            font-size: 10px;
            line-height: 1;
          }
          .inactive-task {
            opacity: 0.55;
          }
          .task-time {
            font-size: 8px;
            color: #0d9488;
            font-weight: 700;
            margin-left: 3px;
            background: #f0fdfa;
            padding: 0px 3px;
            border-radius: 3px;
            border: 1px solid #ccfbf1;
          }
          .empty-state {
            font-style: italic;
            color: #94a3b8;
            font-size: 10px;
            padding: 20px;
            text-align: center;
            background: white;
            border: 1px dashed #cbd5e1;
            border-radius: 8px;
          }
          .footer {
            text-align: center;
            font-size: 9px;
            color: #475569;
            border-top: 1.5px solid #0f766e;
            padding-top: 6px;
            margin-top: 12px;
            font-weight: 650;
            letter-spacing: 0.025em;
          }
        </style>
      </head>
      <body>
        <div class="watermark">
          <svg viewBox="0 0 120 120" style="width: 100%; height: 100%;">
            <defs>
              <linearGradient id="wmSkyGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stop-color="#f97316" />
                <stop offset="60%" stop-color="#f59e0b" />
                <stop offset="100%" stop-color="#eab308" />
              </linearGradient>
              <radialGradient id="wmSunGrad" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stop-color="#ffffff" />
                <stop offset="35%" stop-color="#fef08a" />
                <stop offset="100%" stop-color="#f59e0b" stop-opacity="0" />
              </radialGradient>
              <linearGradient id="wmSolarGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#1e3a8a" />
                <stop offset="100%" stop-color="#1d4ed8" />
              </linearGradient>
              <linearGradient id="wmLeafGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="#4ade80" />
                <stop offset="100%" stop-color="#15803d" />
              </linearGradient>
              <linearGradient id="wmRingGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#166534" />
                <stop offset="100%" stop-color="#14532d" />
              </linearGradient>
            </defs>
            <circle cx="60" cy="60" r="56" fill="none" stroke="#ea580c" stroke-width="2.5" />
            <circle cx="60" cy="60" r="53" fill="none" stroke="#ffffff" stroke-width="1" />
            <g clip-path="url(#wmLogoCircleClip)">
              <clipPath id="wmLogoCircleClip">
                <circle cx="60" cy="60" r="52" />
              </clipPath>
              <rect x="0" y="0" width="120" height="120" fill="url(#wmSkyGrad)" />
              <g opacity="0.3">
                <line x1="60" y1="5" x2="60" y2="115" stroke="#fef08a" stroke-width="1" />
                <line x1="5" y1="60" x2="115" y2="60" stroke="#fef08a" stroke-width="1" />
                <line x1="21" y1="21" x2="99" y2="99" stroke="#fef08a" stroke-width="1" />
                <line x1="21" y1="99" x2="99" y2="21" stroke="#fef08a" stroke-width="1" />
              </g>
              <circle cx="60" cy="40" r="30" fill="url(#wmSunGrad)" opacity="0.9" />
              <circle cx="60" cy="40" r="14" fill="#ffffff" />
              <path d="M5,75 Q30,62 60,68 T115,75 L115,120 L5,120 Z" fill="#15803d" opacity="0.35" />
              <path d="M5,82 Q30,72 60,78 T115,82 L115,120 L5,120 Z" fill="#14532d" />
              <g transform="translate(1, -2)">
                <line x1="22" y1="82" x2="22" y2="102" stroke="#475569" stroke-width="2" />
                <line x1="54" y1="85" x2="54" y2="104" stroke="#475569" stroke-width="2" />
                <line x1="16" y1="92" x2="60" y2="92" stroke="#334155" stroke-width="1.5" />
                <polygon points="12,54 62,64 54,92 6,80" fill="url(#wmSolarGrad)" stroke="#0f172a" stroke-width="1.5" />
                <line x1="24" y1="56" x2="18" y2="83" stroke="#93c5fd" stroke-width="0.75" opacity="0.8" />
                <line x1="37" y1="59" x2="31" y2="86" stroke="#93c5fd" stroke-width="0.75" opacity="0.8" />
                <line x1="50" y1="62" x2="44" y2="89" stroke="#93c5fd" stroke-width="0.75" opacity="0.8" />
                <line x1="11" y1="62" x2="60" y2="72" stroke="#93c5fd" stroke-width="0.75" opacity="0.8" />
                <line x1="9" y1="71" x2="57" y2="81" stroke="#93c5fd" stroke-width="0.75" opacity="0.8" />
              </g>
              <g transform="translate(12, -4)">
                <path d="M68,85 Q78,74 80,58" fill="none" stroke="#4ade80" stroke-width="3" stroke-linecap="round" />
                <path d="M80,58 Q66,51 60,59 Q72,64 80,58 Z" fill="url(#wmLeafGrad)" stroke="#166534" stroke-width="0.5" />
                <path d="M80,58 Q70,55 60,59" fill="none" stroke="#14532d" stroke-width="0.75" />
                <path d="M80,58 Q95,51 101,59 Q89,64 80,58 Z" fill="url(#wmLeafGrad)" stroke="#166534" stroke-width="0.5" />
                <path d="M80,58 Q90,55 101,59" fill="none" stroke="#14532d" stroke-width="0.75" />
              </g>
              <path d="M5,62 A52,52 0 0 0 115,62 A52,53 0 0 1 5,62 Z" fill="url(#wmRingGrad)" />
              <g opacity="0.95">
                <path d="M18,68 Q38,62 55,73 Q58,75 55,78 Q38,68 16,80 T18,68 Z" fill="#22c55e" stroke="#14532d" stroke-width="0.75" />
                <path d="M102,68 Q82,62 65,73 Q62,75 65,78 Q82,68 104,80 T102,68 Z" fill="#16a34a" stroke="#14532d" stroke-width="0.75" />
                <path d="M46,72 C48,70 52,70 54,72 L58,76 M42,75 C44,73 48,73 50,75 L54,79 M38,78 C40,76 44,76 46,78 L49,81" fill="none" stroke="#ffffff" stroke-width="1.25" stroke-linecap="round" />
              </g>
            </g>
          </svg>
        </div>

        <div class="header">
          <div class="header-left">
            <svg viewBox="0 0 120 120" class="header-logo" style="height: 48px; width: 48px; display: inline-block; vertical-align: middle;">
              <defs>
                <linearGradient id="skyGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stop-color="#f97316" />
                  <stop offset="60%" stop-color="#f59e0b" />
                  <stop offset="100%" stop-color="#eab308" />
                </linearGradient>
                <radialGradient id="sunGrad" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stop-color="#ffffff" />
                  <stop offset="35%" stop-color="#fef08a" />
                  <stop offset="100%" stop-color="#f59e0b" stop-opacity="0" />
                </radialGradient>
                <linearGradient id="solarGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stop-color="#1e3a8a" />
                  <stop offset="100%" stop-color="#1d4ed8" />
                </linearGradient>
                <linearGradient id="leafGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stop-color="#4ade80" />
                  <stop offset="100%" stop-color="#15803d" />
                </linearGradient>
                <linearGradient id="ringGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stop-color="#166534" />
                  <stop offset="100%" stop-color="#14532d" />
                </linearGradient>
              </defs>
              <circle cx="60" cy="60" r="56" fill="none" stroke="#ea580c" stroke-width="2.5" />
              <circle cx="60" cy="60" r="53" fill="none" stroke="#ffffff" stroke-width="1" />
              <g clip-path="url(#logoCircleClip)">
                <clipPath id="logoCircleClip">
                  <circle cx="60" cy="60" r="52" />
                </clipPath>
                <rect x="0" y="0" width="120" height="120" fill="url(#skyGrad)" />
                <g opacity="0.3">
                  <line x1="60" y1="5" x2="60" y2="115" stroke="#fef08a" stroke-width="1" />
                  <line x1="5" y1="60" x2="115" y2="60" stroke="#fef08a" stroke-width="1" />
                  <line x1="21" y1="21" x2="99" y2="99" stroke="#fef08a" stroke-width="1" />
                  <line x1="21" y1="99" x2="99" y2="21" stroke="#fef08a" stroke-width="1" />
                </g>
                <circle cx="60" cy="40" r="30" fill="url(#sunGrad)" opacity="0.9" />
                <circle cx="60" cy="40" r="14" fill="#ffffff" />
                <path d="M5,75 Q30,62 60,68 T115,75 L115,120 L5,120 Z" fill="#15803d" opacity="0.35" />
                <path d="M5,82 Q30,72 60,78 T115,82 L115,120 L5,120 Z" fill="#14532d" />
                <g transform="translate(1, -2)">
                  <line x1="22" y1="82" x2="22" y2="102" stroke="#475569" stroke-width="2" />
                  <line x1="54" y1="85" x2="54" y2="104" stroke="#475569" stroke-width="2" />
                  <line x1="16" y1="92" x2="60" y2="92" stroke="#334155" stroke-width="1.5" />
                  <polygon points="12,54 62,64 54,92 6,80" fill="url(#solarGrad)" stroke="#0f172a" stroke-width="1.5" />
                  <line x1="24" y1="56" x2="18" y2="83" stroke="#93c5fd" stroke-width="0.75" opacity="0.8" />
                  <line x1="37" y1="59" x2="31" y2="86" stroke="#93c5fd" stroke-width="0.75" opacity="0.8" />
                  <line x1="50" y1="62" x2="44" y2="89" stroke="#93c5fd" stroke-width="0.75" opacity="0.8" />
                  <line x1="11" y1="62" x2="60" y2="72" stroke="#93c5fd" stroke-width="0.75" opacity="0.8" />
                  <line x1="9" y1="71" x2="57" y2="81" stroke="#93c5fd" stroke-width="0.75" opacity="0.8" />
                </g>
                <g transform="translate(12, -4)">
                  <path d="M68,85 Q78,74 80,58" fill="none" stroke="#4ade80" stroke-width="3" stroke-linecap="round" />
                  <path d="M80,58 Q66,51 60,59 Q72,64 80,58 Z" fill="url(#leafGrad)" stroke="#166534" stroke-width="0.5" />
                  <path d="M80,58 Q70,55 60,59" fill="none" stroke="#14532d" stroke-width="0.75" />
                  <path d="M80,58 Q95,51 101,59 Q89,64 80,58 Z" fill="url(#leafGrad)" stroke="#166534" stroke-width="0.5" />
                  <path d="M80,58 Q90,55 101,59" fill="none" stroke="#14532d" stroke-width="0.75" />
                </g>
                <path d="M5,62 A52,52 0 0 0 115,62 A52,53 0 0 1 5,62 Z" fill="url(#ringGrad)" />
                <g opacity="0.95">
                  <path d="M18,68 Q38,62 55,73 Q58,75 55,78 Q38,68 16,80 T18,68 Z" fill="#22c55e" stroke="#14532d" stroke-width="0.75" />
                  <path d="M102,68 Q82,62 65,73 Q62,75 65,78 Q82,68 104,80 T102,68 Z" fill="#16a34a" stroke="#14532d" stroke-width="0.75" />
                  <path d="M46,72 C48,70 52,70 54,72 L58,76 M42,75 C44,73 48,73 50,75 L54,79 M38,78 C40,76 44,76 46,78 L49,81" fill="none" stroke="#ffffff" stroke-width="1.25" stroke-linecap="round" />
                </g>
              </g>
            </svg>
            <div class="header-titles" style="display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center;">
              <div class="logo-text" style="color: #0f5132; font-weight: 800; font-size: 20px; line-height: 1.2; margin: 0; display: flex; align-items: center; justify-content: center; gap: 4px;">Saurya <span style="color: #ea580c; font-weight: 900;">Mitra</span></div>
              <div style="display: flex; align-items: center; justify-content: center; gap: 4px; margin-top: 3.5px;">
                <div style="height: 2px; width: 10px; background-color: #ea580c; opacity: 0.6;"></div>
                <div style="font-size: 9px; font-weight: 800; color: #0f5132; letter-spacing: 0.05em; text-transform: uppercase; white-space: nowrap;">Together for a Solar Future</div>
                <div style="height: 2px; width: 10px; background-color: #ea580c; opacity: 0.6;"></div>
              </div>
            </div>
          </div>
          <div class="timestamp">
            <strong>${isBn ? 'রিপোর্ট তৈরির সময়:' : 'Report Time:'}</strong> ${timestamp}<br>
            <strong>${isBn ? 'আইডি:' : 'Report ID:'}</strong> SM-LOG-${Math.floor(100000 + Math.random() * 900000)}
          </div>
        </div>

        <h2 class="report-title">${isBn ? 'অফিসিয়াল সৌর মিত্র রক্ষণাবেক্ষণ ও সুরক্ষা রিপোর্ট' : 'Official Saurya Mitra Maintenance & Security Report'}</h2>

        <div class="sections-container">
          <!-- Section A: Upcoming Schedule -->
          <div class="section">
            <div class="section-title">
              📅 ${isBn ? 'সেকশন এ: আগামী রক্ষণাবেক্ষণের সময়সূচী (ACTIVE REMINDERS)' : 'Section A: Upcoming Schedule (Active Reminders)'}
            </div>
            ${upcomingDatesHtml}
          </div>

          <!-- Section B: Maintenance Log History & Timestamps -->
          <div class="section">
            <div class="section-title">
              🛡️ ${isBn ? 'সেকশন বি: রক্ষণাবেক্ষণের ইতিহাস ও টাইমস্ট্যাম্প' : 'Section B: History Log & Timestamps'}
            </div>
            ${pastDatesHtml}
          </div>
        </div>

        <div class="footer">
          Report Analysis by Saurya Mitra AI – Designed and developed by Sukanta Nandi.
        </div>

        <script>
          window.focus();
          setTimeout(function() {
            window.print();
          }, 400);
        </script>
      </body>
      </html>
    `);
    printWindow.document.close();
  };

  const completedCount = content.checklistItems.filter(item => activeChecklist[item.id]?.checked).length;
  const progressPercent = Math.round((completedCount / content.checklistItems.length) * 100);

  return (
    <div id="maintenance-panel" className="bg-[#FCFBF7] border border-amber-200/50 rounded-[2.5rem] p-6 md:p-10 shadow-xl max-w-5xl mx-auto space-y-10 text-left">
      
      {/* Premium Header Accent banner */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-6 border-b border-amber-100">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-100 text-emerald-800 rounded-full text-xs font-black uppercase tracking-widest">
            <Wrench className="w-3.5 h-3.5" />
            {isBn ? 'কেয়ার গাইড ২০২৬' : 'System Longevity V2'}
          </div>
          <h2 className="text-3xl md:text-4xl font-black text-slate-900 tracking-tight leading-tight">
            {content.title}
          </h2>
          <p className="text-sm md:text-base font-medium text-gray-500 max-w-2xl">
            {content.subtitle}
          </p>
        </div>
        
        {/* Animated Efficiency Badge */}
        <div className="flex items-center gap-4 bg-gradient-to-br from-emerald-500 to-teal-600 text-white p-4 rounded-3xl shadow-lg shadow-emerald-200/50 self-stretch md:self-auto justify-center">
          <div className="text-left">
            <span className="text-[9px] font-black tracking-widest uppercase text-emerald-100 block">{isBn ? 'উৎপাদন বৃদ্ধি' : 'Efficiency Boost'}</span>
            <span className="text-2xl font-extrabold leading-none">+25% to 30%</span>
          </div>
          <div className="w-9 h-9 bg-white/20 rounded-full flex items-center justify-center">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>
      </div>

      <p className="text-base text-gray-700 leading-relaxed font-medium bg-amber-50/40 p-4 rounded-2xl border border-amber-100/40">
        {content.intro}
      </p>

      {/* Grid containing core steps: interactive and eye-soothing */}
      <div className="space-y-4">
        <h3 className="text-lg font-black text-slate-800 flex items-center gap-2">
          <span className="w-2.5 h-5 rounded bg-amber-500 inline-block" />
          {content.sec1Title}
        </h3>
        <p className="text-xs font-bold text-gray-400 uppercase tracking-widest pl-4">{content.sec1Sub}</p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-2">
          {content.cleaningPoints.map((item, idx) => {
            const IconComponent = item.icon;
            return (
              <motion.div
                key={idx}
                whileHover={{ y: -5, boxShadow: "0 15px 30px -10px rgba(0,0,0,0.08)" }}
                onClick={() => setActiveCard(activeCard === idx ? null : idx)}
                className={`p-5 rounded-3xl border transition-all duration-300 cursor-pointer text-left relative overflow-hidden bg-white ${item.borderColor} ${
                  activeCard === idx ? 'ring-2 ring-amber-400' : ''
                }`}
              >
                <div className="flex items-start gap-4">
                  <div className={`p-3 rounded-2xl ${item.bgColor} ${item.iconColor}`}>
                    <IconComponent className="w-6 h-6" />
                  </div>
                  <div className="space-y-1 pr-6">
                    <h4 className="font-extrabold text-slate-800 text-base flex items-center gap-1.5">
                      {item.title}
                    </h4>
                    <p className="text-sm text-gray-600 leading-relaxed font-semibold">
                      {item.desc}
                    </p>
                  </div>
                </div>
                
                {/* Visual accent corner decoration */}
                <div className="absolute right-3 top-3 w-4 h-4 text-slate-300">
                  <Info className="w-3.5 h-3.5 opacity-40" />
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Inverter Section - Premium Layout */}
      <div className="bg-gradient-to-br from-slate-900 to-slate-950 text-white rounded-[2rem] p-6 md:p-8 border border-slate-800 shadow-xl relative overflow-hidden">
        {/* Glow Effects */}
        <div className="absolute -top-12 -right-12 w-36 h-36 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-12 -left-12 w-36 h-36 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center gap-3 border-b border-slate-800 pb-5 mb-5">
          <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-2xl border border-amber-500/20">
            <Cpu className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-black text-white">{content.sec2Title}</h3>
            <p className="text-xs text-amber-400 font-extrabold uppercase tracking-wider mt-0.5">{content.sec2Sub}</p>
          </div>
        </div>

        <p className="text-sm text-slate-300 leading-relaxed mb-6 font-medium">
          {content.sec2Desc}
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {content.inversionPoints.map((point, i) => (
            <div key={i} className="bg-slate-900/60 border border-slate-800/80 p-4.5 rounded-2xl space-y-2">
              <div className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center text-[11px] font-black border border-amber-400/20">
                {i + 1}
              </div>
              <h4 className="font-extrabold text-slate-100 text-sm">{point.title}</h4>
              <p className="text-xs text-slate-400 leading-relaxed font-semibold">{point.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Grid of structure and wiring */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
        {/* Wiring Card */}
        <div className="p-6 bg-[#FAF9F5] border border-stone-200/60 rounded-3xl space-y-3">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-100 text-indigo-700 rounded-xl">
              <Zap className="w-5 h-5 animate-pulse" />
            </div>
            <h4 className="font-extrabold text-slate-800 text-base">{content.sec3Title}</h4>
          </div>
          <p className="text-sm text-gray-600 leading-relaxed font-semibold pl-1">
            {content.sec3Desc}
          </p>
        </div>

        {/* Structure Card */}
        <div className="p-6 bg-[#F5FAF6] border border-emerald-100/80 rounded-3xl space-y-3">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-100 text-emerald-700 rounded-xl">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h4 className="font-extrabold text-[#1a5f36] text-base">{content.sec4Title}</h4>
          </div>
          <p className="text-sm text-emerald-950/80 leading-relaxed font-semibold pl-1">
            {content.sec4Desc}
          </p>
        </div>
      </div>

      {/* Pro-Tip Highlighter box */}
      <div className="p-5 bg-amber-500/10 border-l-4 border-amber-500 rounded-r-2xl space-y-1.5">
        <h4 className="font-black text-amber-950 tracking-wider text-sm flex items-center gap-1.5 uppercase">
          <Sun className="w-4 h-4 text-amber-600 animate-spin" style={{ animationDuration: '10s' }} />
          {content.proTipTitle}
        </h4>
        <p className="text-xs md:text-sm text-amber-900 leading-relaxed font-semibold">
          {content.proTipDesc}
        </p>
      </div>

      {/* Interactive Checker Module */}
      <div id="interactive-checker-container" className="bg-gradient-to-b from-[#e2e5ea] via-[#d4d8df] to-[#c5cac2]/95 border border-white/60 rounded-[2.5rem] p-6 md:p-9 shadow-[0_30px_70px_-15px_rgba(0,0,0,0.15),inset_0_2.5px_4px_rgba(255,255,255,0.95),inset_0_-8px_24px_rgba(0,0,0,0.06)] space-y-6 relative overflow-hidden">
        
        {/* Specular Curved Gloss Reflection (Lens Flare / Glass boundary) */}
        <div className="absolute top-0 left-0 right-0 h-[45%] bg-gradient-to-b from-white/28 via-white/[0.02] to-transparent rounded-t-[2.5rem] pointer-events-none z-10" style={{ clipPath: 'ellipse(140% 70% at 50% 10%)' }} />

        {/* Hyper-realistic 3D Metal Corner Screws */}
        <div className="absolute top-4 left-4 w-5 h-5 rounded-full bg-gradient-to-tr from-slate-400 via-slate-200 to-white shadow-[1px_1.5px_2.5px_rgba(0,0,0,0.25),inset_-1px_-1px_2px_rgba(0,0,0,0.2),inset_1px_1px_2px_rgba(255,255,255,0.7)] flex items-center justify-center select-none pointer-events-none opacity-80 z-20">
          <div className="w-[12px] h-[2px] bg-slate-500/80 rounded-sm transform rotate-45" />
          <div className="absolute w-[12px] h-[2px] bg-slate-500/80 rounded-sm transform -rotate-45" />
        </div>
        <div className="absolute top-4 right-4 w-5 h-5 rounded-full bg-gradient-to-tr from-slate-400 via-slate-200 to-white shadow-[1px_1.5px_2.5px_rgba(0,0,0,0.25),inset_-1px_-1px_2px_rgba(0,0,0,0.2),inset_1px_1px_2px_rgba(255,255,255,0.7)] flex items-center justify-center select-none pointer-events-none opacity-80 z-20">
          <div className="w-[12px] h-[2px] bg-slate-500/80 rounded-sm transform -rotate-[15deg]" />
          <div className="absolute w-[12px] h-[2px] bg-slate-500/80 rounded-sm transform rotate-[75deg]" />
        </div>
        <div className="absolute bottom-4 left-4 w-5 h-5 rounded-full bg-gradient-to-tr from-slate-400 via-slate-200 to-white shadow-[1px_1.5px_2.5px_rgba(0,0,0,0.25),inset_-1px_-1px_2px_rgba(0,0,0,0.2),inset_1px_1px_2px_rgba(255,255,255,0.7)] flex items-center justify-center select-none pointer-events-none opacity-80 z-20">
          <div className="w-[12px] h-[2px] bg-slate-500/80 rounded-sm transform rotate-[55deg]" />
          <div className="absolute w-[12px] h-[2px] bg-slate-500/80 rounded-sm transform -rotate-[35deg]" />
        </div>
        <div className="absolute bottom-4 right-4 w-5 h-5 rounded-full bg-gradient-to-tr from-slate-400 via-slate-200 to-white shadow-[1px_1.5px_2.5px_rgba(0,0,0,0.25),inset_-1px_-1px_2px_rgba(0,0,0,0.2),inset_1px_1px_2px_rgba(255,255,255,0.7)] flex items-center justify-center select-none pointer-events-none opacity-80 z-20">
          <div className="w-[12px] h-[2px] bg-slate-500/80 rounded-sm transform rotate-[110deg]" />
          <div className="absolute w-[12px] h-[2px] bg-slate-500/80 rounded-sm transform rotate-[20deg]" />
        </div>

        {/* Dynamic Glass Sheen sweep effect */}
        <motion.div 
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent pointer-events-none z-10"
          style={{ skewX: -20 }}
          animate={{ x: ['-100%', '200%'] }}
          transition={{ repeat: Infinity, repeatDelay: 7, duration: 2.2, ease: "easeInOut" }}
        />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-300 pb-5 px-1 relative z-10">
          <div>
            <h4 id="checklist-tracker-title" className="font-black text-slate-800 text-lg md:text-xl tracking-tight leading-none flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-[0_0_8px_#22d3ee,0_0_2.5px_#22d3ee]" />
              {content.checklistTitle}
            </h4>
            <p className="text-[10px] text-slate-500 font-extrabold mt-2 uppercase tracking-wider">{content.checklistSubtitle}</p>
          </div>
          
          <div className="flex flex-wrap items-center gap-4 self-start sm:self-auto">
            {/* Custom Dynamic Color-Coded Calendar Dropdown Popover */}
            <div id="maintenance-date-selector-wrapper" className="relative">
              <div 
                id="maintenance-date-selector-btn" 
                onClick={() => {
                  setShowCalendar(!showCalendar);
                  if (!showCalendar) {
                    setCalendarViewDate(new Date(selectedDate || todayStr));
                  }
                }}
                className="flex items-center gap-2 bg-gradient-to-b from-white to-[#f0f2f5] border border-slate-300 rounded-xl px-3.5 py-2 text-slate-700 font-extrabold text-xs shadow-sm hover:border-amber-400 hover:shadow-md transition-all duration-200 cursor-pointer select-none active:scale-95"
              >
                {formatToMMDDYYYY(selectedDate)}
                <Calendar className="w-3.5 h-3.5 text-amber-500" />
              </div>

              {showCalendar && (
                <>
                  {/* Click outside backdrop overlay to dismiss calendar */}
                  <div className="fixed inset-0 z-40" onClick={() => setShowCalendar(false)} />
                  
                  {/* Custom Calendar Dropdown Card Container */}
                  <div 
                    id="custom-calendar-popup" 
                    className="absolute right-0 mt-2 bg-white border border-slate-250 rounded-2xl p-4 w-[280px] shadow-2xl z-50 text-left animate-fade-in"
                  >
                    {/* Header: Month name and Next/Prev Month togglers */}
                    <div className="flex items-center justify-between mb-3 border-b border-gray-100 pb-2">
                      <span className="text-xs font-black text-slate-800 uppercase tracking-tight">
                        {getMonthName(calendarViewDate)}, {calendarViewDate.getFullYear()}
                      </span>
                      <div className="flex items-center gap-1">
                        <button 
                          onClick={handlePrevMonth} 
                          className="p-1 hover:bg-amber-50 text-amber-900 rounded-lg transition"
                          title={isBn ? 'পূর্ববর্তী মাস' : 'Previous Month'}
                        >
                          <ChevronLeft size={16} className="text-slate-600" />
                        </button>
                        <button 
                          onClick={handleNextMonth} 
                          className="p-1 hover:bg-amber-50 text-amber-900 rounded-lg transition"
                          title={isBn ? 'পরবর্তী মাস' : 'Next Month'}
                        >
                          <ChevronRight size={16} className="text-slate-600" />
                        </button>
                      </div>
                    </div>

                    {/* Weekdays indicator letters */}
                    <div className="grid grid-cols-7 gap-1 text-center mb-1 text-[10px] font-black text-slate-400 uppercase tracking-wider">
                      <span>{isBn ? 'সোম' : 'Mo'}</span>
                      <span>{isBn ? 'মঙ্গল' : 'Tu'}</span>
                      <span>{isBn ? 'বুধ' : 'We'}</span>
                      <span>{isBn ? 'বৃহ' : 'Th'}</span>
                      <span>{isBn ? 'শুক্র' : 'Fr'}</span>
                      <span>{isBn ? 'শনি' : 'Sa'}</span>
                      <span>{isBn ? 'রবি' : 'Su'}</span>
                    </div>

                    {/* Days grid logic with standard color assignment rules */}
                    <div className="grid grid-cols-7 gap-1.5">
                      {(() => {
                        const year = calendarViewDate.getFullYear();
                        const month = calendarViewDate.getMonth();
                        const daysInMonth = getDaysInMonth(year, month);
                        const firstDayIdx = getFirstDayOfMonth(year, month);
                        
                        const daysArray: Array<{ dateStr: string; dayNum: number; isCurrentMonth: boolean }> = [];
                        
                        // Trailing days of previous month
                        const prevMonth = month === 0 ? 11 : month - 1;
                        const prevYear = month === 0 ? year - 1 : year;
                        const daysInPrevMonth = getDaysInMonth(prevYear, prevMonth);
                        for (let i = firstDayIdx - 1; i >= 0; i--) {
                          const dStr = `${prevYear}-${String(prevMonth + 1).padStart(2, '0')}-${String(daysInPrevMonth - i).padStart(2, '0')}`;
                          daysArray.push({ dateStr: dStr, dayNum: daysInPrevMonth - i, isCurrentMonth: false });
                        }
                        
                        // Current month days
                        for (let i = 1; i <= daysInMonth; i++) {
                          const dStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
                          daysArray.push({ dateStr: dStr, dayNum: i, isCurrentMonth: true });
                        }
                        
                        // Leading days of next month
                        const nextMonth = month === 11 ? 0 : month + 1;
                        const nextYear = month === 11 ? year + 1 : year;
                        const remaining = 42 - daysArray.length;
                        for (let i = 1; i <= remaining; i++) {
                          const dStr = `${nextYear}-${String(nextMonth + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
                          daysArray.push({ dateStr: dStr, dayNum: i, isCurrentMonth: false });
                        }
                        
                        return daysArray.map((day, idx) => {
                          const dStr = day.dateStr;
                          const isSel = selectedDate === dStr;
                          
                          let dayStyle = "";
                          let tooltip = "";
                          
                          const dateTasks = history[dStr] || {};
                          const completed = Object.values(dateTasks).filter((t: any) => t.checked).length;
                          const total = content.checklistItems.length;
                          
                          if (!day.isCurrentMonth) {
                            dayStyle = "text-slate-350 opacity-45 hover:bg-amber-50/10";
                          } else {
                            dayStyle = "text-slate-700 font-bold hover:bg-amber-50";
                          }
                          
                          let badgeEl = null;
                          if (completed === total && total > 0) {
                            dayStyle += " bg-emerald-50 text-emerald-850 border border-emerald-250 font-black";
                            const isUpcoming = dStr > todayStr;
                            tooltip = isUpcoming
                              ? (isBn ? `${dStr}: সব কাজ পুরোপুরি নির্ধারিত` : `${dStr}: All tasks fully assigned`)
                              : (isBn ? `${dStr}: সমস্ত কাজ সফলভাবে সম্পন্ন করা হয়েছে` : `${dStr}: All tasks fully completed`);
                            badgeEl = <span className="absolute bottom-1 right-1 w-1 h-1 rounded-full bg-emerald-500" />;
                          } else if (completed > 0) {
                            dayStyle += " bg-amber-50 text-amber-850 border border-amber-250 font-black";
                            const isUpcoming = dStr > todayStr;
                            tooltip = isUpcoming
                              ? (isBn ? `${dStr}: আংশিক কাজ নির্ধারিত` : `${dStr}: Partially assigned`)
                              : (isBn ? `${dStr}: আংশিক কাজ সম্পন্ন` : `${dStr}: Partially completed`);
                            badgeEl = <span className="absolute bottom-1 right-1 w-1 h-1 rounded-full bg-amber-500 animate-pulse" />;
                          } else if (dStr > todayStr && Object.keys(dateTasks).length > 0) {
                            dayStyle += " bg-blue-50 text-blue-800 border border-blue-200";
                            tooltip = isBn ? `${dStr}: রক্ষণাবেক্ষণের সময়সূচী নির্ধারিত` : `${dStr}: Scheduled run`;
                            badgeEl = <span className="absolute bottom-1 right-1 w-1 h-1 rounded-full bg-blue-500 animate-bounce" />;
                          }
                          
                          if (isSel) {
                            dayStyle = "bg-amber-500 text-white font-extrabold shadow-md ring-2 ring-amber-400 scale-105 hover:bg-amber-600";
                          }
                          
                          return (
                            <button
                              key={idx}
                              type="button"
                              onClick={() => {
                                handleDateChange(dStr);
                                setShowCalendar(false);
                              }}
                              className={cn(
                                "relative flex items-center justify-center w-8 h-8 rounded-lg text-xs font-semibold select-none transition cursor-pointer active:scale-90",
                                dayStyle
                              )}
                              title={tooltip || dStr}
                            >
                              <span>{day.dayNum}</span>
                              {badgeEl}
                            </button>
                          );
                        });
                      })()}
                    </div>
                    {/* Popover actions for Today and Clear */}
                    <div className="flex items-center justify-between mt-3 pt-2 border-t border-gray-100 text-[10px] font-black uppercase">
                      <button
                        type="button"
                        onClick={handleTodayClick}
                        className="text-amber-600 hover:text-amber-700 cursor-pointer"
                      >
                        {isBn ? 'আজ' : 'Today'}
                      </button>
                      <button
                        type="button"
                        onClick={handleClear}
                        className="text-gray-400 hover:text-gray-500 cursor-pointer"
                      >
                        {isBn ? 'বন্ধ' : 'Clear'}
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Download Maintenance Report Button */}
            <button
              id="download-maintenance-report-btn"
              onClick={handleDownloadReport}
              className="flex items-center gap-2 bg-gradient-to-b from-white to-[#f0f2f5] hover:from-[#f0f2f5] hover:to-white text-slate-700 border border-slate-300 rounded-xl px-4 py-2 transition-all duration-200 cursor-pointer select-none font-bold text-xs shadow-sm hover:shadow-md active:scale-95"
              title={isBn ? 'রক্ষণাবেক্ষণ রিপোর্ট ডাউনলোড করুন' : 'Download Maintenance Report'}
            >
              <FileDown className="w-4 h-4 text-slate-600" />
              <span>{isBn ? 'ডাউনলোড রিপোর্ট' : 'Download Report'}</span>
            </button>
          </div>
        </div>

        {/* Real-time checklist progress track styled as a tactile hardware analog VU level/LED meter */}
        <div className="bg-[#121620] p-4.5 rounded-2xl border border-slate-400/40 shadow-[inset_0_4px_8px_rgba(0,0,0,0.55),0_1.5px_2px_rgba(255,255,255,0.7)] flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div className="flex items-center gap-2.5 flex-wrap">
            <span className="text-[11px] font-black tracking-widest text-[#94a3b8] font-mono uppercase flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-500 shadow-[0_0_8px_#10b981]" />
              {isBn ? 'এনালগ ভোল্টেজ মিটার' : 'ANALOG LEVEL VU METER'}:
            </span>
            <span className="font-mono text-cyan-400 bg-slate-900/65 border border-cyan-500/25 px-2.5 py-0.5 rounded-lg text-xs font-black shadow-[inset_0_1.5px_3px_rgba(0,0,0,0.5)]">
              {selectedDate}
            </span>
          </div>
          
          <div className="flex items-center gap-3">
            {/* 3D Glass LED meter segment array */}
            <div className="flex items-center gap-1.5 bg-[#0b0e14] px-4 py-2.5 rounded-xl border border-slate-800 shadow-[inset_0_2.5px_6px_rgba(0,0,0,0.7)]">
              {Array.from({ length: content.checklistItems.length }).map((_, idx) => {
                const isLit = completedCount > idx;
                let colorClass = "";
                if (isLit) {
                  if (idx < 3) colorClass = "bg-gradient-to-b from-amber-300 to-amber-500 shadow-[0_0_10px_#f59e0b,0_0_3px_#f59e0b,inset_0_1px_1.5px_rgba(255,255,255,0.7)]";
                  else if (idx < 5) colorClass = "bg-gradient-to-b from-teal-300 to-teal-500 shadow-[0_0_12px_#14b8a6,0_0_3px_#14b8a6,inset_0_1px_1.5px_rgba(255,255,255,0.7)]";
                  else colorClass = "bg-gradient-to-b from-emerald-300 to-emerald-500 shadow-[0_0_14px_#10b981,0_0_4px_#10b981,inset_0_1px_1.5px_rgba(255,255,255,0.7)]";
                } else {
                  colorClass = "bg-[#252e3e]/70 shadow-[inset_0_1px_2px_rgba(0,0,0,0.5)]";
                }
                return (
                  <div 
                    key={idx} 
                    className={cn(
                      "w-5 h-3.5 rounded-sm transition-all duration-300 border border-black/45", 
                      colorClass
                    )} 
                    title={isBn ? `ধাপ ${idx+1}` : `Step ${idx+1}`}
                  />
                );
              })}
            </div>
            
            {/* Percentage Indicator screen */}
            <span className="font-mono text-[12px] font-black bg-[#0b0e14] text-cyan-400 px-3 py-2 rounded-xl border border-slate-800 shadow-[inset_0_2.5px_5px_rgba(0,0,0,0.7)]">
              {progressPercent}%
            </span>
          </div>
        </div>

        {/* The interactive checklist rendered as high-fidelity tactile 3D physical sequencer-keys */}
        <div className="space-y-4 text-left relative z-10">
          {content.checklistItems.map((item) => {
            const isChecked = activeChecklist[item.id]?.checked || false;
            const checkedTime = activeChecklist[item.id]?.timestamp || '';
            
            return (
              <div 
                key={item.id}
                onClick={() => toggleCheck(item.id)}
                className={cn(
                  "p-4 md:p-5 rounded-2xl border transition-all duration-300 flex items-center gap-4.5 cursor-pointer select-none active:scale-[0.995]",
                  isChecked 
                    ? "bg-gradient-to-b from-[#cad0db] to-[#dadfe8] border-t-slate-400/35 border-b-white/55 border-l-slate-350/50 border-r-slate-350/50 shadow-[inset_0_4px_10px_rgba(0,0,0,0.1),inset_0_1px_3px_rgba(0,0,0,0.08),0_1.5px_2px_rgba(255,255,255,0.75)]" 
                    : "bg-gradient-to-b from-[#f3f5f8] to-[#e6e9f0] border-t-white border-b-[#b5bac1] border-l-[#d2d7df] border-r-[#d2d7df] shadow-[0_5px_9px_-2px_rgba(0,0,0,0.06),0_1.5px_2.5px_rgba(0,0,0,0.03),inset_0_1px_1.5px_rgba(255,255,255,0.85)] hover:from-[#f7f9fc] hover:to-[#ebedf5] hover:-translate-y-0.5"
                )}
              >
                <div className="shrink-0 flex items-center justify-center">
                  <div className={cn(
                    "w-8.5 h-8.5 rounded-full border-2 transition-all duration-300 flex items-center justify-center select-none shadow-[0_3px_5px_rgba(0,0,0,0.12),0_1.5px_2px_rgba(0,0,0,0.08)]",
                    isChecked 
                      ? "bg-gradient-to-b from-[#323a45] to-[#20262e] border-[#9298a1] shadow-[inset_0_2px_4px_rgba(0,0,0,0.45)]" 
                      : "bg-gradient-to-b from-[#f2f4f8] to-[#d8dce6] border-[#cbd0da] shadow-[inset_0_1px_1.5px_rgba(255,255,255,1)]"
                  )}>
                    {/* Inner Glowing Indicator Led */}
                    <div className={cn(
                      "w-3.5 h-3.5 rounded-full transition-all duration-300",
                      isChecked
                        ? "bg-gradient-to-b from-cyan-300 via-cyan-400 to-cyan-500 shadow-[0_0_12px_#06b6d4,0_0_4px_#22d3ee,inset_0_1px_2px_rgba(255,255,255,0.85)]"
                        : "bg-gradient-to-b from-slate-400/40 to-slate-500/40 shadow-[inset_0_1px_2.5px_rgba(0,0,0,0.3)]"
                    )} />
                  </div>
                </div>

                <div className="space-y-1.5 flex-1 min-w-0">
                  <p className={cn(
                    "text-xs md:text-sm font-semibold leading-relaxed transition-colors duration-200",
                    isChecked ? "text-slate-400 font-medium" : "text-slate-700 font-bold"
                  )}>
                    {item.text}
                  </p>
                  {isChecked && checkedTime && (
                    <span className="inline-flex items-center gap-1.5 text-[9.5px] font-bold text-cyan-800 bg-cyan-100/60 border border-cyan-200/50 px-2.5 py-0.5 rounded-full shadow-xs">
                      ⏱ {isBn ? 'যাচাইকৃত' : 'Checked'}: {checkedTime}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

          {/* DUAL-COLUMN DESKTOP VIEW SECTION */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-5 border-t border-amber-100/50 mt-4">
          
          {/* COLUMN 1: UPCOMING SCHEDULE (ACTIVE REMINDERS) */}
          <div className="space-y-3 text-left">
            <h5 className="font-extrabold text-[#111827] text-xs uppercase tracking-wider flex items-center gap-1.5 pb-1 border-b border-gray-100">
              <Clock className="w-3.5 h-3.5 text-blue-600 animate-pulse" />
              {isBn ? 'আগামী রক্ষণাবেক্ষণের সময়সূচী (ACTIVE REMINDERS)' : 'Upcoming Schedule (Active Reminders)'}
            </h5>
            
            {upcomingDates.length === 0 ? (
              <p className="text-xs text-slate-400 italic font-semibold py-4">
                {isBn ? 'কোনো রক্ষণাবেক্ষণের সময়সূচী নির্ধারিত নেই। এটি সেট করতে ক্যালেন্ডারে ভবিষ্যতের তারিখ নির্বাচন করুন।' : 'No pending maintenance runs scheduled. Select a future date from the date picker to add one.'}
              </p>
            ) : (
              <div className="space-y-2">
                {upcomingDates.map((dateStr) => {
                  const dateTasks = history[dateStr] || {};
                  const completed = Object.values(dateTasks).filter(t => t.checked).length;
                  const total = content.checklistItems.length;
                  const isEditing = selectedDate === dateStr;
                  
                  return (
                    <div 
                      key={dateStr} 
                      className={cn(
                        "p-3 rounded-xl border transition-all duration-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs",
                        isEditing 
                          ? "bg-blue-50/70 border-blue-400 ring-1 ring-blue-500/20" 
                          : "bg-[#FFFDFB] hover:bg-amber-50/20 border-gray-150 shadow-xs"
                      )}
                    >
                      {/* Left: Metadata Info */}
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-slate-800 flex items-center gap-1">
                          <span>📅</span> <span className="font-mono">{dateStr}</span>
                        </span>
                        <span className="px-1.5 py-0.5 bg-yellow-100 text-[#854d0e] border border-yellow-200 text-[9px] font-black rounded-md uppercase tracking-wide">
                          {isBn ? 'পেন্ডিং' : 'Pending'}
                        </span>
                        <span className="px-1.5 py-0.5 bg-blue-50 text-blue-800 border border-blue-100 text-[9px] font-extrabold rounded-md">
                          {completed}/{total} {isBn ? 'কাজ' : 'checked'}
                        </span>
                      </div>

                      {/* Right: Actions */}
                      <div className="flex items-center gap-1.5 ml-auto shrink-0">
                        {rescheduleDateId === dateStr ? (
                          <div className="flex items-center gap-1 bg-white p-1 rounded-lg border border-blue-300 shadow-sm animate-fade-in">
                            <input
                              type="date"
                              value={tempNewDate}
                              min={todayStr}
                              onChange={(e) => setTempNewDate(e.target.value)}
                              className="bg-gray-50 border border-gray-200 rounded px-1.5 py-0.5 text-xs font-bold text-slate-800 focus:outline-none"
                            />
                            <button
                              onClick={() => {
                                rescheduleTask(dateStr, tempNewDate);
                                setRescheduleDateId(null);
                              }}
                              className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-[10px] rounded transition cursor-pointer"
                            >
                              {isBn ? 'সেভ' : 'Save'}
                            </button>
                            <button
                              onClick={() => setRescheduleDateId(null)}
                              className="px-2 py-1 bg-gray-100 hover:bg-gray-200 text-stone-600 font-extrabold text-[10px] rounded transition cursor-pointer"
                            >
                              {isBn ? 'বাতিল' : 'Cancel'}
                            </button>
                          </div>
                        ) : (
                          <>
                            <button
                              onClick={() => handleDateChange(dateStr)}
                              className={cn(
                                "px-2.5 py-1 font-extrabold text-[11px] rounded-lg transition cursor-pointer shadow-xs active:scale-95 border",
                                isEditing
                                  ? "bg-blue-600 text-white hover:bg-blue-700 border-transparent"
                                  : "bg-white border-gray-200 text-blue-700 hover:bg-blue-50/50"
                              )}
                            >
                              {isBn ? 'কাজ এডিট' : 'Edit Tasks'}
                            </button>
                            <button
                              onClick={() => {
                                setRescheduleDateId(dateStr);
                                setTempNewDate(dateStr);
                              }}
                              className="px-2.5 py-1 bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-[11px] border border-transparent rounded-lg transition cursor-pointer shadow-xs active:scale-95"
                            >
                              {isBn ? 'রিশিডিউল' : 'Reschedule'}
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* COLUMN 2: HISTORY LOG (PAST RECORDS WITH ACCORDION COLLAPSIBLE UI) */}
          <div className="space-y-3 text-left">
            <div className="flex items-center justify-between flex-wrap gap-2 pb-1 border-b border-gray-100">
              <h5 className="font-extrabold text-[#111827] text-xs uppercase tracking-wider flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-650" />
                {isBn ? 'রক্ষণাবেক্ষণের ইতিহাস ও টাইমস্ট্যাম্প' : 'History Log (Past Records)'}
              </h5>
              
              <button
                id="restart-history-btn"
                onClick={() => {
                  setResetOption('history');
                  setShowResetModal(true);
                }}
                className="flex items-center gap-2 px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-extrabold transition-all border shadow-sm bg-white border-red-200/60 text-red-600 hover:text-white hover:bg-gradient-to-r hover:from-red-600 hover:to-orange-500 hover:border-transparent cursor-pointer select-none active:scale-95 duration-200"
              >
                <RotateCcw className="w-4 h-4 text-amber-500 animate-spin-reverse-slow shrink-0" />
                {isBn ? 'সব রিসেট করুন (Reset All)' : 'Reset All'}
              </button>
            </div>
            
            {pastDates.length === 0 ? (
              <p className="text-xs text-slate-400 italic font-semibold py-4">
                {isBn ? 'কোনো অতীত রেকর্ড পাওয়া যায়নি।' : 'No past logs recorded yet.'}
              </p>
            ) : (
              <div className="space-y-2">
                {pastDates.map((dateStr) => {
                  const dateTasks = history[dateStr] || {};
                  const completed = Object.values(dateTasks).filter(t => t.checked).length;
                  const total = content.checklistItems.length;
                  const isActive = selectedDate === dateStr;
                  const isExpanded = !!expandedHistory[dateStr];
                  
                  const toggleHistoryExpand = (dStr: string, e: React.MouseEvent) => {
                    e.stopPropagation();
                    setExpandedHistory(prev => ({
                      ...prev,
                      [dStr]: !prev[dStr]
                    }));
                  };
                  
                  return (
                    <div 
                      key={dateStr}
                      className={cn(
                        "rounded-xl border transition-all duration-200 text-xs text-left",
                        isActive 
                          ? "bg-emerald-50/40 border-emerald-350 shadow-sm" 
                          : "bg-white hover:border-emerald-250 border-gray-150 shadow-2xs"
                      )}
                    >
                      {/* Accordion Row Header: Always visible, extremely clean and condensed */}
                      <div 
                        onClick={(e) => toggleHistoryExpand(dateStr, e)}
                        className="p-3 flex items-center justify-between gap-3 cursor-pointer select-none"
                      >
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-bold text-slate-800 flex items-center gap-1">
                            <span>📅</span> <span className="font-mono">{dateStr}</span>
                          </span>
                          <span className={cn(
                            "px-1.5 py-0.5 border text-[9px] font-black rounded-md uppercase tracking-wider",
                            completed === total 
                              ? "bg-emerald-100 text-emerald-800 border-emerald-200" 
                              : "bg-amber-100 text-amber-800 border-amber-200"
                          )}>
                            {completed === total 
                              ? (isBn ? 'সম্পূর্ণ' : 'Completed') 
                              : (isBn ? 'আংশিক' : 'Partial')
                            }
                          </span>
                          <span className="px-1.5 py-0.5 bg-gray-50 border border-gray-150 text-slate-600 text-[9px] font-extrabold rounded-md">
                            {completed}/{total} {isBn ? 'কাজ' : 'checked'}
                          </span>
                        </div>

                        {/* Action + Chevron Toggler on the right */}
                        <div className="flex items-center gap-1.5 ml-auto shrink-0">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDateChange(dateStr);
                            }}
                            className={cn(
                              "px-2.5 py-1 font-extrabold text-[11px] rounded-lg transition cursor-pointer border shadow-2xs",
                              isActive
                                ? "bg-[#0f766e] text-white hover:bg-[#115e59] border-transparent"
                                : "bg-white border-gray-200 text-[#0f766e] hover:bg-emerald-50/50"
                            )}
                          >
                            {isBn ? 'বিবরণ দেখুন' : 'Inspect'}
                          </button>
                          
                          <div className="p-1 hover:bg-slate-100 rounded-lg text-slate-405 transition">
                            {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                          </div>
                        </div>
                      </div>

                      {/* Accordion Collapsible Detail Drawer: Reveals items checked/not checked in a highly polished sub-view */}
                      {isExpanded && (
                        <div className="px-3 pb-3 pt-1 border-t border-gray-100 text-left bg-slate-50/50 rounded-b-xl space-y-2 animate-fade-in">
                          <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1 mt-1">
                            {isBn ? 'কাজের বিবরণী:' : 'CHECKLIST AUDIT DETAILS:'}
                          </div>
                          <div className="grid grid-cols-1 gap-1.5 pl-1.5">
                            {content.checklistItems.map((chkItem) => {
                              const wasChecked = dateTasks[chkItem.id]?.checked || false;
                              return (
                                <div key={chkItem.id} className="flex items-start gap-2 text-[11px] font-semibold text-slate-605">
                                  <span className="shrink-0 mt-0.5">
                                    {wasChecked ? (
                                      <span className="text-emerald-600 font-extrabold" title={isBn ? 'সম্পন্ন' : 'Completed'}>✓</span>
                                    ) : (
                                      <span className="text-gray-300 font-extrabold" title={isBn ? 'অসম্পূর্ণ' : 'Incomplete'}>○</span>
                                    )}
                                  </span>
                                  <span className={cn(
                                    wasChecked ? "text-slate-800" : "text-slate-400 line-through decoration-gray-300"
                                  )}>
                                    {chkItem.text}
                                  </span>
                                  {wasChecked && dateTasks[chkItem.id]?.timestamp && (
                                    <span className="text-[9px] text-gray-400 font-normal ml-auto font-mono shrink-0">
                                      ⏱ {dateTasks[chkItem.id]?.timestamp}
                                    </span>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>



        {progressPercent === 100 && (
          <motion.div 
            initial={{ opacity: 0, y: 15 }} 
            animate={{ opacity: 1, y: 0 }}
            className="p-3.5 bg-emerald-100 text-emerald-800 border-l-4 border-emerald-500 font-black text-xs md:text-sm rounded-r-xl tracking-wide max-w-md mx-auto text-center shadow-lg"
          >
            🎉 {content.verifiedMsg}
          </motion.div>
        )}
      </div>

      {/* Professional Cost Estimate Contract Block */}
      <div className="space-y-4">
        <h3 className="text-lg font-black text-slate-800 flex items-center gap-2">
          <Coins className="text-amber-500 w-5 h-5" />
          {content.sec5Title}
        </h3>
        <p className="text-xs font-semibold text-gray-500 leading-relaxed max-w-xl">
          {content.sec5Desc}
        </p>

        {/* Custom Premium Cost Table */}
        <div className="overflow-hidden border border-gray-200 rounded-3xl shadow-sm bg-white">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-900 text-white text-[11px] font-black tracking-widest uppercase">
                <th className="p-4 pl-6 w-32 border-r border-slate-800">{content.tableCols.size}</th>
                <th className="p-4 w-48 border-r border-slate-800">{content.tableCols.cost}</th>
                <th className="p-4 pl-6">{content.tableCols.benefits}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 font-semibold text-xs md:text-sm">
              {content.tableRows.map((row, i) => (
                <tr key={i} className="hover:bg-amber-50/20 transition-colors">
                  <td className="p-4 pl-6 font-black text-slate-800 border-r border-gray-100">{row.size}</td>
                  <td className="p-4 font-black text-emerald-600 border-r border-gray-100">{row.cost}</td>
                  <td className="p-4 pl-6 text-gray-600 leading-relaxed font-bold">{row.benefits}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Premium Confirm Reset Modal Overlay with Hyper-Realistic 3D styling */}
      <AnimatePresence>
        {showResetModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop with elegant glassmorphic blur and deep fade transition */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowResetModal(false)}
              className="fixed inset-0 bg-slate-950/80 backdrop-blur-xl"
            />

            {/* Micro background radial lights for true depth illustration */}
            <div className="absolute top-1/4 left-1/4 w-80 h-80 bg-amber-400/10 rounded-full filter blur-[100px] pointer-events-none z-10" />
            <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-red-500/10 rounded-full filter blur-[100px] pointer-events-none z-10" />

            {/* Modal Box with premium high-end spring floating physics */}
            <motion.div
              initial={{ scale: 0.92, opacity: 0, y: 35 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.92, opacity: 0, y: 35 }}
              transition={{ type: "spring", damping: 25, stiffness: 350 }}
              className="relative bg-white/95 border border-white/80 backdrop-blur-md rounded-[2.5rem] p-8 max-w-md w-full shadow-[0_35px_80px_-15px_rgba(15,23,42,0.35),0_0_50px_rgba(245,158,11,0.06)] space-y-6 z-20 text-left overflow-hidden ring-1 ring-slate-950/[0.04]"
            >
              {/* Top Accent Gradient Border Glow Line */}
              <div className="absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r from-amber-400 via-orange-400 to-red-500 opacity-80" />

              <div className="flex flex-col items-center gap-3.5 text-center mt-3">
                {/* 3D Bobbing Floating Alert Icon Container */}
                <motion.div 
                  animate={{ y: [0, -6, 0] }}
                  transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
                  className="bg-gradient-to-b from-amber-50 to-amber-100/80 p-4 rounded-full text-amber-500 shadow-[0_10px_25px_-5px_rgba(245,158,11,0.22),inset_0_2px_4px_rgba(255,255,255,1)] border border-amber-200/40"
                >
                  <AlertTriangle className="w-8 h-8" />
                </motion.div>
                <h4 className="text-xl font-black text-slate-900 tracking-tight">
                  {isBn ? 'সিস্টেম রেকর্ড রিসেট' : 'Reset System Records'}
                </h4>
                <p className="text-slate-500 text-[11px] font-bold leading-relaxed max-w-sm px-2">
                  {isBn 
                    ? 'কোন ধরনের মেইনটেন্যান্স রেকর্ড মুছে ফেলতে চান অনুগ্রহ করে নির্বাচন করুন:' 
                    : 'Please select which records you would like to delete:'}
                </p>
              </div>

              {/* Three Interactive Selection Cards */}
              <div className="space-y-3">
                {/* Option 1: History of Past Records */}
                <motion.div 
                  onClick={() => setResetOption('history')}
                  whileHover={{ y: -3, scale: 1.015 }}
                  whileTap={{ scale: 0.995 }}
                  transition={{ type: "spring", stiffness: 450, damping: 25 }}
                  className={`relative flex items-start gap-4 p-4 rounded-[1.5rem] border transition-all duration-300 cursor-pointer select-none ${
                    resetOption === 'history' 
                      ? 'bg-amber-50/50 border-amber-500 shadow-[0_12px_24px_-8px_rgba(245,158,11,0.18)] ring-1 ring-amber-500/35' 
                      : 'border-slate-100 hover:border-slate-200 bg-white/70 hover:bg-white shadow-[0_4px_12px_rgba(0,0,0,0.015)]'
                  }`}
                >
                  <div className="mt-1 flex items-center justify-center">
                    <span className={`w-5 h-5 rounded-full border flex items-center justify-center transition-all duration-300 shadow-inner ${
                      resetOption === 'history' 
                        ? 'border-amber-500 bg-amber-500 shadow-[0_0_12px_rgba(245,158,11,0.45)]' 
                        : 'border-slate-300 bg-white hover:border-slate-400'
                    }`}>
                      {resetOption === 'history' && (
                        <motion.span 
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="w-1.5 h-1.5 rounded-full bg-white" 
                        />
                      )}
                    </span>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className="p-1 rounded-lg bg-amber-50 text-amber-600 border border-amber-200/20">
                        <Clock className="w-3.5 h-3.5" />
                      </span>
                      <h5 className="font-extrabold text-xs text-slate-800">
                        {isBn ? 'হিস্ট্রি লগ (অতীতের রেকর্ড)' : 'History Log (Past Records)'}
                      </h5>
                    </div>
                    <p className="text-[10.5px] text-slate-500 font-semibold mt-1.5 leading-relaxed">
                      {isBn 
                        ? 'আজকের এবং আগের দিনের সমস্ত টাস্ক লগ বা রেকর্ড মুছে ফেলুন।' 
                        : 'Delete all checked task logs from today and previous days.'}
                    </p>
                  </div>
                </motion.div>

                {/* Option 2: Upcoming Schedule */}
                <motion.div 
                  onClick={() => setResetOption('upcoming')}
                  whileHover={{ y: -3, scale: 1.015 }}
                  whileTap={{ scale: 0.995 }}
                  transition={{ type: "spring", stiffness: 450, damping: 25 }}
                  className={`relative flex items-start gap-4 p-4 rounded-[1.5rem] border transition-all duration-300 cursor-pointer select-none ${
                    resetOption === 'upcoming' 
                      ? 'bg-amber-50/50 border-amber-500 shadow-[0_12px_24px_-8px_rgba(245,158,11,0.18)] ring-1 ring-amber-500/35' 
                      : 'border-slate-100 hover:border-slate-200 bg-white/70 hover:bg-white shadow-[0_4px_12px_rgba(0,0,0,0.015)]'
                  }`}
                >
                  <div className="mt-1 flex items-center justify-center">
                    <span className={`w-5 h-5 rounded-full border flex items-center justify-center transition-all duration-300 shadow-inner ${
                      resetOption === 'upcoming' 
                        ? 'border-amber-500 bg-amber-500 shadow-[0_0_12px_rgba(245,158,11,0.45)]' 
                        : 'border-slate-300 bg-white hover:border-slate-400'
                    }`}>
                      {resetOption === 'upcoming' && (
                        <motion.span 
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="w-1.5 h-1.5 rounded-full bg-white" 
                        />
                      )}
                    </span>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className="p-1 rounded-lg bg-amber-50 text-amber-600 border border-amber-200/20">
                        <Calendar className="w-3.5 h-3.5" />
                      </span>
                      <h5 className="font-extrabold text-xs text-slate-800">
                        {isBn ? 'আগামী সময়সূচী (সক্রিয় রিমাইন্ডার)' : 'Upcoming Schedule (Active Reminders)'}
                      </h5>
                    </div>
                    <p className="text-[10.5px] text-slate-500 font-semibold mt-1.5 leading-relaxed">
                      {isBn 
                        ? 'ভবিষ্যতের জন্য নির্ধারিত সমস্ত মেইনটেন্যান্স বা সময়সূচী মুছে ফেলুন।' 
                        : 'Remove all future dates scheduled for maintenance.'}
                    </p>
                  </div>
                </motion.div>

                {/* Option 3: ALL */}
                <motion.div 
                  onClick={() => setResetOption('all')}
                  whileHover={{ y: -3, scale: 1.015 }}
                  whileTap={{ scale: 0.995 }}
                  transition={{ type: "spring", stiffness: 450, damping: 25 }}
                  className={`relative flex items-start gap-4 p-4 rounded-[1.5rem] border transition-all duration-300 cursor-pointer select-none ${
                    resetOption === 'all' 
                      ? 'bg-red-50/50 border-red-500 shadow-[0_12px_24px_-8px_rgba(239,68,68,0.22)] ring-1 ring-red-500/35' 
                      : 'border-slate-100 hover:border-slate-200 bg-white/70 hover:bg-white shadow-[0_4px_12px_rgba(0,0,0,0.015)]'
                  }`}
                >
                  <div className="mt-1 flex items-center justify-center">
                    <span className={`w-5 h-5 rounded-full border flex items-center justify-center transition-all duration-300 shadow-inner ${
                      resetOption === 'all' 
                        ? 'border-red-500 bg-red-500 shadow-[0_0_12px_rgba(239,68,68,0.45)]' 
                        : 'border-slate-300 bg-white hover:border-slate-400'
                    }`}>
                      {resetOption === 'all' && (
                        <motion.span 
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="w-1.5 h-1.5 rounded-full bg-white" 
                        />
                      )}
                    </span>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className="p-1 rounded-lg bg-red-100/60 text-red-700 border border-red-200/20">
                        <AlertTriangle className="w-3.5 h-3.5" />
                      </span>
                      <h5 className="font-extrabold text-xs text-red-700">
                        {isBn ? 'সব (ALL)' : 'ALL'}
                      </h5>
                    </div>
                    <p className="text-[10.5px] text-slate-500 font-semibold mt-1.5 leading-relaxed">
                      {isBn 
                        ? 'অতীতের ইতিহাস এবং ভবিষ্যতের সময়সূচী সহ সমস্ত ডেটা সম্পূর্ণ মুছে ফেলুন।' 
                        : 'Completely wipe all records, both past logs and upcoming schedule.'}
                    </p>
                  </div>
                </motion.div>
              </div>

              {/* Warning Notice Ribbon */}
              <div className="bg-red-50/50 border border-red-200/40 p-3 rounded-[1.25rem] text-center shadow-[0_2px_10px_rgba(239,68,68,0.02)]">
                <p className="text-[10px] text-red-600 font-black tracking-widest uppercase flex items-center justify-center gap-1.5">
                  <span>⚠️</span>
                  <span>{isBn ? 'এই পদক্ষেপটি ফিরিয়ে আনা যাবে না' : 'This action is irreversible'}</span>
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-3.5 w-full pt-1">
                <button
                  id="modal-confirm-no"
                  onClick={() => setShowResetModal(false)}
                  className="flex-1 px-5 py-3.5 bg-slate-50 hover:bg-slate-100 text-slate-700 font-extrabold text-xs rounded-2xl border border-slate-200/80 transition-all duration-200 cursor-pointer active:scale-[0.97] hover:shadow-[0_4px_12px_rgba(0,0,0,0.05)] text-center select-none"
                >
                  {isBn ? 'বাতিল করুন' : 'Cancel'}
                </button>
                <button
                  id="modal-confirm-yes"
                  onClick={confirmResetHistory}
                  className="flex-1 px-5 py-3.5 bg-gradient-to-r from-red-600 to-red-500 hover:from-red-700 hover:to-red-600 text-white font-extrabold text-xs rounded-2xl cursor-pointer active:scale-[0.97] transition-all duration-200 shadow-[0_10px_20px_-5px_rgba(239,68,68,0.3)] hover:shadow-[0_12px_24px_-5px_rgba(239,68,68,0.4)] text-center select-none"
                >
                  {isBn ? 'রিসেট নিশ্চিত করুন' : 'Confirm Reset'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
